# from datadeal import combine_all, batchFun, DataDel
# from gadgetM import process_modis, inver_modis
from algorithms.trainM import  Network, Kdtune
from algorithms.plotM import ploot, crop_image, batch_crop, batch_ploot
import time
start = time.time()
#combine_all("dataiii", "data/cmodis")
# pci = batchFun("data//cmodis")
# pci.batch(inver_modis)
# print('###################')
# pci = batchFun("data//GPT//Grmodis")
# pci.batch(DataDel.del_modislse_gpt)
# import pandas as pd
# from sklearn.model_selection import train_test_split
#batch_crop('result_1')
# # 读取文本文件到 DataFrame
# file_path = 'data\GPT\Gdmodis\china6.txt'  # 替换为你的文件路径
# df = pd.read_csv(file_path, comment=';', header=None, sep='\t')

# # 将数据划分为80%训练集和20%测试集
# train_df, test_df = train_test_split(df, test_size=0.2, random_state=42)

# # 保存训练集和测试集到新的txt文件
# train_df.to_csv('data\GPT\Gdmodis\china6_rain.txt', index=False, header=False, sep='\t')
# test_df.to_csv('data\GPT\Gdmodis\china6_test.txt', index=False, header=False, sep='\t')

# DataDel.random_sample('data//china7.txt', 'data//cn10w.txt', 100000)
# DataDel.random_sample('data//china7.txt', 'data//cn1w.txt', 10000)
# DataDel.random_sample('data//china7.txt', 'data//cn1k.txt', 1000)
# DataDel.random_sample('data//china7.txt', 'data//cn1h.txt', 100)
# G:\gu\geogpt\envGeo\Scripts\python.exe
layer = [
    {'type': 'Dense', 'units': 128, 'activation': 'relu'},
    {'type': 'Dense', 'units': 64, 'activation': 'relu'},
    {'type': 'Dense', 'units': 64, 'activation': 'relu'},
    {'type': 'Dense', 'units': 32, 'activation': 'relu'},
]
layerk = [
    {'type': 'Dense', 'units': 128, 'activation': 'relu'},
    {'type': 'Dense', 'units': 64, 'activation': 'relu'},
    {'type': 'Dense', 'units': 64, 'activation': 'relu'},
    {'type': 'Dense', 'units': 32, 'activation': 'relu'},
    {'type': 'KalmanFilter'},   
]
# Network(f'result_1//LMI1').train('data\moni\data1.txt', layer,  [0,1,2,3,4], [7])
# Network(f'result_1//LMI4').train('data\moni\data4.txt', layer,  [0,1,2,3,4], [7])
# Network(f'result_1//AILMI1').train('data\moni\data1.txt', layer,  [0,1,2,3,4,5,6], [7])
# Network(f'result_1//AILMI4').train('data\moni\data4.txt', layer,  [0,1,2,3,4,5,6], [7])
#labels = {5: 'LST(K)', 6: 'LSE10', 7: 'LSE11', 8: 'LSE12', 9: 'LSE13', 10: 'LSE14'}
#batch_ploot('result_aster')
# for out, label in labels.items():
#     print(f"Output: {out}, Label: {label}")

    # Network(f'result_aster//a6_{label}').train('data/aster/concat6.txt', layer,  [0,1,2,3,4], [out])

    # Network(f'result_aster//a39_{label}').train('data/aster/ddrc063915.txt', layer,  [0,1,2,3,4], [out])


    # Network(f'result_aster//a40_{label}').train('data/aster/ddrc064017.txt', layer,  [0,1,2,3,4], [out])

    # Kdtune(f'result_aster//ka40_{label}').tuner(f'result_aster//a6_{label}/concat6.h5', 'data/aster/ddrc064017.txt', [0,1,2,3,4], [out], 0.3)
    # Kdtune(f'result_aster//ka39_{label}').tuner(f'result_aster//a6_{label}/concat6.h5', 'data/aster/ddrc063915.txt', [0,1,2,3,4], [out], 0.3)

    # Network(f'result_aster//a40_{label}').predict(f'result_aster//a6_{label}/concat6.h5', 'data/aster/ddrc064017.txt',[0,1,2,3,4], [out])
    # Network(f'result_aster//a39_{label}').predict(f'result_aster//a6_{label}/concat6.h5', 'data/aster/ddrc063915.txt',[0,1,2,3,4], [out])



end = time.time()

elapsed_time = end - start

print(f"代码运行时间：{elapsed_time:.2f} 秒")

hours, remainder = divmod(elapsed_time, 3600)
minutes, seconds = divmod(remainder, 60)
print(f"代码运行时间：{int(hours)} 小时 {int(minutes)} 分钟 {seconds:.2f} 秒")  # 优化此行
# 1
# Network('0803').train('data\dmodis\drc230803.txt', layer,  [0,1,2,3,4], [7])
# Network('0804').train('data\dmodis\drc230804.txt', layer,  [0,1,2,3,4], [7])
# Network('0805').train('data\dmodis\drc230805.txt', layer,  [0,1,2,3,4], [7])
# Network('0806').train('data\dmodis\drc230806.txt', layer,  [0,1,2,3,4], [7])
# Network('0807').train('data\dmodis\drc230807.txt', layer,  [0,1,2,3,4], [7])
# Network('0808').train('data\dmodis\drc230808.txt', layer,  [0,1,2,3,4], [7])
# Network('0809').train('data\dmodis\drc230809.txt', layer,  [0,1,2,3,4], [7])
# Network('0810').train('data\dmodis\drc230810.txt', layer,  [0,1,2,3,4], [7])
# 2
# Network('result_1/08cv.5').cross_validate('data\dmodis\drc230808.txt', layer,  [0,1,2,3,4], [7], 0.5)
# 3
# files_to_concat = ['drc230803.txt', 'drc230804.txt', 'drc230805.txt', 'drc230806.txt', 'drc230807.txt', 'cv.5drc230808.txt', 'drc230810.txt']  # 可以是任意数量的文件
# DataDel.concat('data\\dmodis', files_to_concat, 'china7.txt')
# 4
# Network('result_1/test').train('data//cn1h.txt', layer,  [0,1,2,3,4], [7])
# print('-----------------------------cn-------------------------------------')
# Network('result_1/cnLSE31').train('data\china7.txt', layer,  [0,1,2,3,4], [5])
# Network('result_1/cnLSE32').train('data\china7.txt', layer,  [0,1,2,3,4], [6])
# Network('result_1/cnLST').train('data\china7.txt', layer,  [0,1,2,3,4], [7])
# print('------------------c8----------------------')
# Network('result_1/c8LSE31').train('data\drc230808.txt', layer,  [0,1,2,3,4], [5])
# Network('result_1/c8LSE32').train('data\drc230808.txt', layer,  [0,1,2,3,4], [6])
# Network('result_1/c8LST').train('data\drc230808.txt', layer,  [0,1,2,3,4], [7])
# print('------------------c9----------------------')
# Network('result_1/c9LSE31').train('data\drc230809.txt', layer,  [0,1,2,3,4], [5])
# Network('result_1/c9LSE32').train('data\drc230809.txt', layer,  [0,1,2,3,4], [6])
# Network('result_1/c9LST').train('data\drc230809.txt', layer,  [0,1,2,3,4], [7])
# print('------------------Gcn----------------------')
# Network('result_1/cnGLSE31').train('data\china7.txt', layerk,  [0,1,2,3,4,6], [5])
# Network('result_1/cnGLSE32').train('data\china7.txt', layerk,  [0,1,2,3,4,5], [6])
# Network('result_1/cnGLST').train('data\china7.txt', layerk,  [0,1,2,3,4,5,6], [7])
# 5
# Kdtune('result_1/K8LSE31').tuner('result_1\cnGLSE31\china7.h5', 'data\drc230808.txt', [0,1,2,3,4,6], [5], 0.3)
# Kdtune('result_1/K8LSE32').tuner('result_1\cnGLSE32\china7.h5', 'data\drc230808.txt', [0,1,2,3,4,5], [6], 0.3)
# Kdtune('result_1/K8LST').tuner('result_1\cnGLST\china7.h5', 'data\drc230808.txt', [0,1,2,3,4,5,6], [7], 0.3)
# Kdtune('result_1/K9LSE31').tuner('result_1\cnGLSE31\china7.h5', 'data\drc230809.txt', [0,1,2,3,4,6], [5], 0.3)
# Kdtune('result_1/K9LSE32').tuner('result_1\cnGLSE32\china7.h5', 'data\drc230809.txt', [0,1,2,3,4,5], [6], 0.3)
# Kdtune('result_1/K9LST').tuner('result_1\cnGLST\china7.h5', 'data\drc230809.txt', [0,1,2,3,4,5,6], [7], 0.3)
# 6
# Network('result_1/c8LSE31').predict('result_1\cnGLSE31\china7.h5', 'data\dmodis\drc230808.txt',[0,1,2,3,4,6], [5])
# Network('result_1/c8LSE32').predict('result_1\cnGLSE32\china7.h5', 'data\dmodis\drc230808.txt',[0,1,2,3,4,5], [6])
# Network('result_1/c8LST').predict('result_1\cnGLST\china7.h5', 'data\dmodis\drc230808.txt',[0,1,2,3,4,5,6], [7])
# Network('result_1/c9LSE31').predict('result_1\cnGLSE31\china7.h5', 'data\dmodis\drc230809.txt',[0,1,2,3,4,6], [5])
# Network('result_1/c9LSE32').predict('result_1\cnGLSE32\china7.h5', 'data\dmodis\drc230809.txt',[0,1,2,3,4,5], [6])
# Network('result_1/c9LST').predict('result_1\cnGLST\china7.h5', 'data\dmodis\drc230809.txt',[0,1,2,3,4,5,6], [7])
# 7
# ploot('result_1\cnGLSE31\china7_test.txt', 'LSE31')
# ploot('result_1\cnGLSE32\china7_test.txt', 'LSE32')
# ploot('result_1\cnGLST\china7_test.txt', 'LST(K)')
# ploot('result_1\cnLSE31\china7_test.txt', 'LSE31')
# ploot('result_1\cnLSE32\china7_test.txt', 'LSE32')
# ploot('result_1\cnLST\china7_test.txt', 'LST(K)')

# ploot('result_1\c8LSE31\drc230808_test.txt', 'LSE31')
# ploot('result_1\c8LSE32\drc230808_test.txt', 'LSE32')
# ploot('result_1\c8LST\drc230808_test.txt', 'LST(K)')
# ploot('result_1\c9LSE31\drc230809_test.txt', 'LSE31')
# ploot('result_1\c9LSE32\drc230809_test.txt', 'LSE32')
# ploot('result_1\c9LST\drc230809_test.txt', 'LST(K)')

# ploot('result_1\K8LSE31\drc230808_test_KD.txt', 'LSE31')
# ploot('result_1\K8LSE32\drc230808_test_KD.txt', 'LSE32')
# ploot('result_1\K8LST\drc230808_test_KD.txt', 'LST(K)')
# ploot('result_1\K9LSE31\drc230809_test_KD.txt', 'LSE31')
# ploot('result_1\K9LSE32\drc230809_test_KD.txt', 'LSE32')
# ploot('result_1\K9LST\drc230809_test_KD.txt', 'LST(K)')

# ploot('result_1\c8LSE31\predict_drc230808.txt', 'LSE31')
# ploot('result_1\c8LSE32\predict_drc230808.txt', 'LSE32')
# ploot('result_1\c8LST\predict_drc230808.txt', 'LST(K)')
# ploot('result_1\c9LSE31\predict_drc230809.txt', 'LSE31')
# ploot('result_1\c9LSE32\predict_drc230809.txt', 'LSE32')
# ploot('result_1\c9LST\predict_drc230809.txt', 'LST(K)')
#
# ploot('result_1\ZERA5c8\predict_dlrc230808ME.txt', 'LST(K)')
# ploot('result_1\ZERA5c9\predict_dlrc230809ME.txt', 'LST(K)')
# ploot('result_1\ZERA5k8\predict_dlrc230808ME.txt', 'LST(K)')
# ploot('result_1\ZERA5k9\predict_dlrc230809ME.txt', 'LST(K)')




