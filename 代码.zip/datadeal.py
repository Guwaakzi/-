import os
import pandas as pd
from tqdm import tqdm
import datetime
import time
import re
import numpy as np
import time
#from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error


class DataDel:
    @staticmethod
    def del_zero(file_path):
        output_file = os.path.join(os.path.dirname(file_path), "d" + os.path.basename(file_path))

        # 读取文本文件到 DataFrame
        #df.iloc[:, 17] = df.iloc[:, 17].astype(str)
        df = pd.read_csv(file_path, comment=';', header=None, sep='\t', dtype={17: str})

        # 统计每列0值的数量
        c_llh = df[df.iloc[:, 0] == 0].shape[0]
        c_em = df[df.iloc[:, 3] == 0].shape[0]
        c_lst = df[df.iloc[:, 15] == 0].shape[0]

        # 删除含有0值的行
        df = df[(df.iloc[:, 0] != 0) & (df.iloc[:, 3] != 0) & (df.iloc[:, 15] != 0)]

        # 输出信息
        print(f"Number of rows with 0 in the first column: {c_llh}")
        print(f"Number of rows with 0 in the fourth column: {c_em}")
        print(f"Number of rows with 0 in the sixteenth column: {c_lst}")
        print(f"Number of rows after processing: {df.shape[0]}")

        # 保存处理后的数据
        df.to_csv(output_file, index=False, header=False, sep='\t')

    @staticmethod
    def dell(file_path):
        output_file = os.path.join(os.path.dirname(file_path), "d" + os.path.basename(file_path))

        # 读取文本文件到 DataFrame
        df = pd.read_csv(file_path, comment=';', header=None, sep='\t', dtype={17: str})
        all = df.shape[0]

        # 统计每列0值的数量
        c_llh = df.iloc[:, 0] != 0
        n = 1
        c_em1 = ((286 - n) <= df.iloc[:, 3]) & (df.iloc[:, 3] <= (321 + n))
        c_em2 = ((282 - n) <= df.iloc[:, 4]) & (df.iloc[:, 4] <= (314 + n))
        c_em3 = ((279 - n) <= df.iloc[:, 5]) & (df.iloc[:, 5] <= (310 + n))
        c_em4 = ((271 - n) <= df.iloc[:, 6]) & (df.iloc[:, 6] <= (302 + n))
        c_em5 = ((274 - n) <= df.iloc[:, 7]) & (df.iloc[:, 7] <= (304 + n))
        c_em6 = ((274 - n) <= df.iloc[:, 8]) & (df.iloc[:, 8] <= (303 + n))
        c_lst = ((274 - n) <= df.iloc[:, 15])

        # 分析每个十进制数值出现的次数
        # df['decimal'] = df.iloc[:, 17].apply(lambda x: int(x, 2))
        # value_counts = df['decimal'].value_counts()
        # value_counts.to_csv(output_file, sep='\t', index=True, header=False)

        # 输出信息

        print('............................................')
        print(f"Number of rows with 0 in the  llh : {all - c_llh.shape[0]}")
        print('............................................')
        print(f"Number of rows deleted due to em 1: {all - df[c_em1].shape[0]}")
        print(f"Number of rows deleted due to em 2: {all - df[c_em2].shape[0]}")
        print(f"Number of rows deleted due to em 3: {all - df[c_em3].shape[0]}")
        print(f"Number of rows deleted due to em 4: {all - df[c_em4].shape[0]}")
        print(f"Number of rows deleted due to em 5: {all - df[c_em5].shape[0]}")
        print(f"Number of rows deleted due to em 6: {all - df[c_em6].shape[0]}")
        print(f"Number of rows deleted due to lst : {all - df[c_lst].shape[0]}")

        # 删除含有0值的行
        df = df[c_em1 & c_em2 & c_em3 & c_em4 & c_em5 & c_em6 & c_lst]
        # 保存处理后的数据
        df.to_csv(output_file, index=False, header=False, sep='\t')

        print(f"Number of rows before processing: {all}")
        print(f"Number of rows after  processing: {df.shape[0]}")

    @staticmethod
    def del_anyzero(file_path):
        output_file = os.path.join(os.path.dirname(file_path), "d" + os.path.basename(file_path))

        # 读取文本文件到 DataFrame
        df = pd.read_csv(file_path, comment=';', header=None, sep='\t')

        # 删除含有0值的行
        rows_before = df.shape[0]
        #df = df[~(df == 0).any(axis=1) & ~(df.iloc[:, 5] == 200)]  # 删除任意一列为零的行
        df = df[~(df == 0).any(axis=1) & (df.iloc[:, 5] > 300) & (df.iloc[:, 6] < 1) & (df.iloc[:, 7] < 1) & (df.iloc[:, 8] < 1) & (df.iloc[:, 9] < 1) & (df.iloc[:, 10] < 1)]

        rows_after = df.shape[0]

        # 输出信息
        print(f"Number of rows before processing: {rows_before}")
        print(f"Number of rows after processing: {rows_after},and del:{rows_before - rows_after}")

        # 保存处理后的数据
        df.to_csv(output_file, index=False, header=False, sep='\t')

    @staticmethod
    def shushu(file_path):

        df = pd.read_csv(file_path, comment=';', header=None, sep='\t')
        n = 1

        c1 = df[(n < df.iloc[:, 6])]
        c2 = df[(n < df.iloc[:, 7])]
        c3 = df[(n < df.iloc[:, 8])]
        c4 = df[(n < df.iloc[:, 9])]
        c5 = df[(n < df.iloc[:, 10])]

        print(f'c1 is {c1.shape[0]}')
        print(f'c2 is {c2.shape[0]}')
        print(f'c3 is {c3.shape[0]}')
        print(f'c4 is {c4.shape[0]}')
        print(f'c5 is {c5.shape[0]}')



    @staticmethod
    def concat(path, file_list, name):
        # 读取所有文件并将它们合并为一个DataFrame
        file_paths = [os.path.join(path, file) for file in file_list]
        #dfs = [pd.read_csv(file, sep="\t", header=None) for file in file_paths]
        dfs = [pd.read_csv(file, sep="\t", header=None, usecols=range(8)) for file in file_paths]  # 只读取每个文件的前十列

        final_data = pd.concat(dfs, ignore_index=True)
        final_data = final_data.sample(frac=1).reset_index(drop=True)   #随机

        # 构造输出文件路径并保存合并后的数据
        save_path = os.path.join(path, name)
        final_data.to_csv(save_path, sep='\t', index=False, header=False)

        @staticmethod     
        def del_modislst(file_path):
            output_file = os.path.join('data/dmodis', "d" + os.path.basename(file_path))
            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            # 读取文本文件到 DataFrame
            df = pd.read_csv(file_path, comment=';', header=None, sep='\t')
            
            rows_before = df.shape[0]
            
            
            # 计算每列被筛选掉的行数
            cols_filtered = [df[df[col] == 0].shape[0] for col in range(6)] + [df[df[6] != 0].shape[0]]
            for i, count in enumerate(cols_filtered, start=1):
                print(f"第{i}列被筛选掉的数据: {count}")
            
            # 应用筛选条件
            df_filtered = df[(df.iloc[:, :6] != 0).all(axis=1) & (df.iloc[:, 6] == 0)]
            rows_after = df_filtered.shape[0]
            
            # 输出信息
            print(f"原始数据总行数: {rows_before}")
            print(f"筛选后的数据总行数: {rows_after}")
            print(f"被筛选掉的数据行数: {rows_before - rows_after}")
            print(f'保留率{rows_after / rows_before}')
            
            # 保存处理后的数据
            df_filtered.to_csv(output_file, index=False, header=False, sep='\t')
    
    @staticmethod   
    def del_modislse_t(file_path):
        output_file = os.path.join('data/dmodis', "d" + os.path.basename(file_path))
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        # 读取文本文件到 DataFrame
        df = pd.read_csv(file_path, comment=';', header=None, sep='\t')
        rows_before = df.shape[0]
        
        # 计算每列被筛选掉的行数
        cols_filtered = [df[df[col] == 0].shape[0] for col in range(8)]  # 对前8列计算值为0的行数
        cols_filtered += [df[df[5] >= 1].shape[0]]  # 第6列值大于等于1的行数
        cols_filtered += [df[df[6] >= 1].shape[0]]  # 第7列值大于等于1的行数
        cols_filtered += [df[df[8] != 0].shape[0]]  # 第9列值不等于0的行数

        for i, count in enumerate(cols_filtered, start=1):
            print(f"第{i}列被筛选掉的数据: {count}")
        
        # 应用筛选条件
        condition = (df.iloc[:, :8] != 0).all(axis=1) & (df.iloc[:, 5] < 1) & (df.iloc[:, 6] < 1) & (df.iloc[:, 8] == 0)
        df_filtered = df[condition]
        rows_after = df_filtered.shape[0]
        
        # 输出信息
        print(f"原始数据总行数: {rows_before}")
        print(f"筛选后的数据总行数: {rows_after}")
        print(f"被筛选掉的数据行数: {rows_before - rows_after}")
        print(f'保留率: {rows_after / rows_before:.2%}')
        
        # 保存处理后的数据
        df_filtered.to_csv(output_file, index=False, header=False, sep='\t')

    @staticmethod   
    def del_modislse_gpt(file_path):
        output_file = os.path.join('data//GPT//Gdmodis', "d" + os.path.basename(file_path))
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        
        # 读取文本文件到 DataFrame
        df = pd.read_csv(file_path, comment=';', header=None, sep='\t')
        rows_before = df.shape[0]
        
        # 计算每列被筛选掉的行数
        cols_filtered = [df[df[col] == 0].shape[0] for col in range(8)]  # 对前8列计算值为0的行数
        cols_filtered += [df[df[8] != 0].shape[0]]  # 第9列值不等于0的行数

        for i, count in enumerate(cols_filtered, start=1):
            print(f"第{i}列被筛选掉的数据: {count}")
        
        # 应用筛选条件
        condition = (df.iloc[:, :8] > 0).all(axis=1) & (df.iloc[:, 8] == 0)
        df_filtered = df[condition]
        rows_after = df_filtered.shape[0]
        
        # 输出信息
        print(f"原始数据总行数: {rows_before}")
        print(f"筛选后的数据总行数: {rows_after}")
        print(f"被筛选掉的数据行数: {rows_before - rows_after}")
        print(f'保留率: {rows_after / rows_before:.2%}')
        
        # 保存处理后的数据
        df_filtered.to_csv(output_file, index=False, header=False, sep='\t')
    
    @staticmethod   
    def random_sample(file_path, output_path, samples):  #取样
        df = pd.read_csv(file_path, comment=';', header=None, sep='\t')
        sample_df = df.sample(n=samples)
        sample_df.to_csv(output_path, index=False, header=False, sep='\t')



if __name__ == "__main__":
    DataDel.dell('E:/Gu/MODIS/deal/txt/drcll.txt')

if __name__ == "__main__":
    DataDel.del_zero('E:/Gu/MODIS/deal/txt/rcll.txt')

if __name__ == "__main__":
    files_to_concat = ['/path/to/file1.txt', '/path/to/file2.txt', '/path/to/file3.txt']  # 可以是任意数量的文件
    DataDel.concat(files_to_concat, 'concat.txt')


class DataProcessor:
    def __init__(self):
        self.samples = None
    def read_file(self, file_path):
        print("Attempting to open file:", file_path)
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            file_content = f.read()
        self.samples = int(re.search(r'(\d+) samples', file_content).group(1))
        return file_content

    def save(self, band_list, output_path, subfolder):
        #output_file = os.path.join(subfolder, "combine", "c" + os.path.basename(output_path))
        output_file = os.path.join(output_path, "c" + os.path.basename(subfolder))
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        print(f'output_file is {output_file}')

        flattened_data_list = []
        for band in band_list:
            for data in band:
                flattened_data = []
                for row in data:
                    flattened_data.extend(row)
                flattened_data_list.append(flattened_data)
        total_rows = len(flattened_data_list[0])
        total_columns = len(band_list)

        with open(output_file, 'w') as f:
            # Write Python-readable comments about the dimensions and generation time
            original_dimensions = f"; Original_Dimensions = {{'samples': {self.samples}, 'lines': {len(band_list[0][0])}, 'bands': {len(band_list[0])}}}\n"
            new_dimensions = f"; New_Dimensions = {{'samples': {total_columns}, 'lines': {total_rows}}}\n"
            generated_time = f"; Generated_Time = '{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}'\n"
            f.write(original_dimensions)
            f.write(new_dimensions)
            f.write(generated_time)

            # Write the flattened and combined data
            format = "{desc} {n_fmt}/{total_fmt} [{bar:30}] {percentage:3.0f}% [{elapsed}<{remaining}, {rate_fmt}{postfix}]"
            for rows in tqdm(zip(*flattened_data_list), desc="Processing Rows", total=len(flattened_data_list[0]),
                             bar_format=format, unit="batch", ascii=".>="):
                combined_row = "\t".join(rows)
                f.write(combined_row + "\n")
        print(f"The file has been saved at: {output_file}")

    def sample(self, file_list):
        all_band_list = []
        format = "{desc} {n_fmt}/{total_fmt} [{bar:30}] {percentage:3.0f}% [{elapsed}<{remaining}, {rate_fmt}{postfix}]"
        for file in tqdm(file_list, desc='Processing file', bar_format=format, unit="batch", ascii=".>="):
            file_content = self.read_file(file)
            file_lines = file_content.strip().split("\n")
            band_data_list = []
            current_band = []
            for line in file_lines:
                line = line.strip()
                if line.startswith(";") or not line:  # Skip comments and empty lines
                    # If we encounter an empty line, it means a new band is starting
                    if not line and current_band:
                        band_data_list.append(current_band)
                        current_band = []
                    continue
                # line_data = list(map(float, line.split()))
                line_data = line.split()
                current_band.append(line_data)
            if current_band:
                band_data_list.append(current_band)
            all_band_list.append(band_data_list)
        return all_band_list


    @staticmethod
    def del_anyzero(file_path):
        output_file = os.path.join(os.path.dirname(file_path), "d", "d" + os.path.basename(file_path))
        os.makedirs(os.path.dirname(output_file), exist_ok=True)
        # 读取文本文件到 DataFrame
        df = pd.read_csv(file_path, comment=';', header=None, sep='\t')
        rows_before = df.shape[0]
        print(f"原始数据总行数: {len(df)}")
        print(f"不包含0的数据: {len(df[~(df == 0).any(axis=1)])}, 被筛选出{len(df) - len(df[~(df == 0).any(axis=1)])}")
        print(f"第6列小于1的数据: {len(df[df.iloc[:, 5] < 1])}, 被筛选出{len(df) - len(df[df.iloc[:, 5] < 1])}")
        print(f"第7列小于1的数据: {len(df[df.iloc[:, 6] < 1])}, 被筛选出{len(df) - len(df[df.iloc[:, 6] < 1])}")
        print(f"第8列小于1的数据: {len(df[df.iloc[:, 7] < 1])}, 被筛选出{len(df) - len(df[df.iloc[:, 7] < 1])}")
        print(f"第9列小于1的数据: {len(df[df.iloc[:, 8] < 1])}, 被筛选出{len(df) - len(df[df.iloc[:, 8] < 1])}")
        print(f"第10列小于1的数据: {len(df[df.iloc[:, 9] < 1])}, 被筛选出{len(df) - len(df[df.iloc[:, 9] < 1])}")
        print(f"第11列不等于200的数据: {len(df[df.iloc[:, 10] != 200])}, 被筛选出{len(df) - len(df[df.iloc[:, 10] != 200])}")


        df = df[~(df == 0).any(axis=1) & (df.iloc[:, 5] < 1) & (df.iloc[:, 6] < 1) & (df.iloc[:, 7] < 1) & (df.iloc[:, 8] < 1) & (df.iloc[:, 9] < 1) & (df.iloc[:, 10] != 200)]

        rows_after = df.shape[0]

        # 输出信息
        print(f"Number of rows before processing: {rows_before}")
        print(f"Number of rows after processing: {rows_after},and del:{rows_before - rows_after}")

        # 保存处理后的数据
        df.to_csv(output_file, index=False, header=False, sep='\t')
    
    @staticmethod
    def process_o(file_path):
        output_file = os.path.join(os.path.dirname(file_path), "d", "d" + os.path.basename(file_path))
        df = pd.read_csv(file_path, comment=';', header=None, sep='\t')
        data = df.loc[~(df == 0).any(axis=1)]
        data.to_csv(output_file, index=False, header=False, sep='\t')
        print(f"Saved cleaned file: {output_file}")
        print(f"原始行数: {df.shape[0]}")
        print(f"新行数: {data.shape[0]}")
        
    @staticmethod
    def remove_outliers(file_path):
        output_file = os.path.join(os.path.dirname(file_path), "d", "d" + os.path.basename(file_path))
        df = pd.read_csv(file_path, comment=';', header=None, sep='\t')

        z_thresh = 2.71828  # 阈值
        rows_to_delete = np.zeros(df.shape[0], dtype=bool)

        print("Before removing outliers:")
        for col in df.columns:
            mean = df[col].mean()
            std_dev = df[col].std()
            print(f'Column {col} - Mean: {mean:.4f}, Std Dev: {std_dev:.4f}')

        for col in df.columns:
            mean = df[col].mean()
            std_dev = df[col].std()

            # 计算 z-scores
            z_scores = np.abs((df[col] - mean) / std_dev)

            # 找出远离均值的值
            outliers = z_scores > z_thresh

            # 打印出远离均值的值的数量
            num_outliers = np.sum(outliers)
            print(f'Column {col} has {num_outliers} outliers.')

            # 标记那些需要删除的行
            rows_to_delete = rows_to_delete | outliers

        # 删除包含远离均值的值的行
        cleaned_data = df[~rows_to_delete]

        print("After removing outliers:")
        for col in cleaned_data.columns:
            mean = cleaned_data[col].mean()
            std_dev = cleaned_data[col].std()
            print(f'Column {col} - Mean: {mean:.4f}, Std Dev: {std_dev:.4f}')

        # 确保输出目录存在
        os.makedirs(os.path.dirname(output_file), exist_ok=True)

        # 保存清理后的数据
        cleaned_data.to_csv(output_file, index=False, header=False, sep='\t')

        # 打印删除前后数据的形状
        print(f"Saved cleaned file: {output_file}")
        print(f"原始行数: {df.shape[0]}")
        print(f"新行数: {cleaned_data.shape[0]}")

    @staticmethod
    def remove_outliers4(file_path):
        output_file = os.path.join(os.path.dirname(file_path), "d", "d" + os.path.basename(file_path))
        df = pd.read_csv(file_path, comment=';', header=None, sep='\t')

        rows_to_delete = np.zeros(df.shape[0], dtype=bool)

        print("Before removing outliers:")
        for col in df.columns:
            # 计算 Q1 和 Q3
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            
            # 计算离群点阈值
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR

            print(f'Column {col} - Q1: {Q1:.4f}, Q3: {Q3:.4f}, IQR: {IQR:.4f}')
            print(f'Column {col} - Lower Bound: {lower_bound:.4f}, Upper Bound: {upper_bound:.4f}')

        for col in df.columns:
            # 计算 Q1, Q3 和 IQR
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            
            # 计算离群点阈值
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            # 找出离群点
            outliers = (df[col] < lower_bound) | (df[col] > upper_bound)
            
            # 打印离群点数量
            num_outliers = np.sum(outliers)
            print(f'Column {col} has {num_outliers} outliers.')
            
            # 标记那些需要删除的行
            rows_to_delete = rows_to_delete | outliers

        # 删除包含离群点的行
        cleaned_data = df[~rows_to_delete]

        print("After removing outliers:")
        for col in cleaned_data.columns:
            mean = cleaned_data[col].mean()
            std_dev = cleaned_data[col].std()
            print(f'Column {col} - Mean: {mean:.4f}, Std Dev: {std_dev:.4f}')

        # 确保输出目录存在
        os.makedirs(os.path.dirname(output_file), exist_ok=True)

        # 保存清理后的数据
        cleaned_data.to_csv(output_file, index=False, header=False, sep='\t')

        # 打印删除前后数据的形状
        print(f"Saved cleaned file: {output_file}")
        print(f"原始行数: {df.shape[0]}")
        print(f"新行数: {cleaned_data.shape[0]}")

    @staticmethod
    def remove_outliers4_bias(file_path):
        output_file = os.path.join(os.path.dirname(file_path), "d", "d" + os.path.basename(file_path))
        df = pd.read_csv(file_path, comment=';', header=None, sep='\t')

        rows_to_delete = np.zeros(df.shape[0], dtype=bool)

        # 计算所有偏差并筛选
        deviations = [
            (df[5] - df[0], '第六列减去第一列'),
            (df[5] - df[1], '第六列减去第二列'),
            (df[6] - df[1], '第七列减去第二列'),
            (df[7] - df[1], '第八列减去第二列'),
            (df[7] - df[2], '第八列减去第三列'),
            (df[8] - df[2], '第九列减去第三列'),
            (df[8] - df[3], '第九列减去第四列'),
            (df[9] - df[3], '第十列减去第四列'),
            (df[9] - df[4], '第十列减去第五列'),
        ]

        for deviation, description in deviations:
            Q1 = deviation.quantile(0.25)
            Q3 = deviation.quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            # 找出离群点
            outliers = (deviation < lower_bound) | (deviation > upper_bound)
            
            # 打印离群点数量
            num_outliers = np.sum(outliers)
            print(f'{description} has {num_outliers} outliers.')
            
            # 如果有离群点，标记行
            rows_to_delete = rows_to_delete | outliers

        # 删除包含离群点的行
        cleaned_data = df[~rows_to_delete]

        print("After removing outliers:")
        for col in cleaned_data.columns:
            mean = cleaned_data[col].mean()
            std_dev = cleaned_data[col].std()
            print(f'Column {col} - Mean: {mean:.4f}, Std Dev: {std_dev:.4f}')

        # 确保输出目录存在
        os.makedirs(os.path.dirname(output_file), exist_ok=True)

        # 保存清理后的数据
        cleaned_data.to_csv(output_file, index=False, header=False, sep='\t')

        # 打印删除前后数据的形状
        print(f"Saved cleaned file: {output_file}")
        print(f"原始行数: {df.shape[0]}")
        print(f"新行数: {cleaned_data.shape[0]}")

    @staticmethod
    def calculate(data):
        columns_pairs = [(6, 11), (7, 12), (8, 13), (9, 14), (10, 15)]
        results = {}
        def calculate_metrics(y_true, y_pred):
            residuals = y_true - y_pred
            positive_residuals = residuals[residuals > 0]
            negative_residuals = residuals[residuals < 0]
    
            metrics = {
                'RSS': np.sum(residuals ** 2),
                'R-squared': r2_score(y_true, y_pred),
                'RMSE': np.sqrt(mean_squared_error(y_true, y_pred)),
                'MAE': mean_absolute_error(y_true, y_pred),
                'Avg Positive Residual': np.mean(positive_residuals) if positive_residuals.size > 0 else 0,
                'Avg Negative Residual': np.mean(negative_residuals) if negative_residuals.size > 0 else 0
            }
            return metrics
        # 遍历列组合并计算指标
        for i, (x_col, y_col) in enumerate(columns_pairs, start=1):
            y_true = data.iloc[:, y_col-1]
            y_pred = data.iloc[:, x_col-1]
            results[f'Pair {i}: Columns {x_col} & {y_col}'] = calculate_metrics(y_true, y_pred)

                # 打印结果
        for pair, metrics in results.items():
            print('********************************************************************')
            print(pair)
            for metric, value in metrics.items():
                print(f'  {metric}: {value:.4f}')


    @staticmethod
    def process_data(file_path):
        output_file_zeros = os.path.join(os.path.dirname(file_path), "d", "d" + os.path.basename(file_path))
        output_file_cleaned = os.path.join(os.path.dirname(file_path), "z", "z" + os.path.basename(file_path))
        os.makedirs(os.path.dirname(output_file_cleaned), exist_ok=True)
        os.makedirs(os.path.dirname(output_file_zeros), exist_ok=True)

        # 读取文本文件到 DataFrame
        df = pd.read_csv(file_path, comment=';', header=None, sep='\t')

        # 条件：行中有零或者第6到10列小于1或者第11列为200
        mask_zeros_any = (df == 0).any(axis=1)
        mask_less_than_one = (df.iloc[:, 5:10] >= 1).any(axis=1)
        mask_column_eleven = (df.iloc[:, 10] == 200)
        print(f"原始数据总行数: {len(df)}")
        print(f"不包含0的数据: {len(df[~(df == 0).any(axis=1)])}, 被筛选出{len(df) - len(df[~(df == 0).any(axis=1)])}")
        print(f"第6列小于1的数据: {len(df[df.iloc[:, 5] < 1])}, 被筛选出{len(df) - len(df[df.iloc[:, 5] < 1])}")
        print(f"第7列小于1的数据: {len(df[df.iloc[:, 6] < 1])}, 被筛选出{len(df) - len(df[df.iloc[:, 6] < 1])}")
        print(f"第8列小于1的数据: {len(df[df.iloc[:, 7] < 1])}, 被筛选出{len(df) - len(df[df.iloc[:, 7] < 1])}")
        print(f"第9列小于1的数据: {len(df[df.iloc[:, 8] < 1])}, 被筛选出{len(df) - len(df[df.iloc[:, 8] < 1])}")
        print(f"第10列小于1的数据: {len(df[df.iloc[:, 9] < 1])}, 被筛选出{len(df) - len(df[df.iloc[:, 9] < 1])}")
        print(f"第11列不等于200的数据: {len(df[df.iloc[:, 10] != 200])}, 被筛选出{len(df) - len(df[df.iloc[:, 10] != 200])}")

        # 替换满足条件的行为零

        df.loc[mask_zeros_any | mask_less_than_one | mask_column_eleven] = 0
        df.to_csv(output_file_zeros, index=False, header=False, sep='\t')
        print(f"Saved file with zeros: {output_file_zeros}")

        # 删除包含零的行
        df_cleaned = df.loc[~(df == 0).any(axis=1)]
        df_cleaned = df_cleaned.sample(frac=1).reset_index(drop=True) #随机
        df_cleaned.to_csv(output_file_cleaned, index=False, header=False, sep='\t')
        print(f"Saved cleaned file: {output_file_cleaned}")
        print(f"原始行数: {df.shape[0]}")
        print(f"新行数: {df_cleaned.shape[0]}")

def combinelist(file_list, output_file, subfolder):
    file_list = [f"{subfolder}/{file}" for file in file_list]
    output_file = f"{subfolder}/{output_file}.txt"
    processor = DataProcessor()
    start = time.time()
    all_band_list = processor.sample(file_list)  # save
    processor.save(all_band_list, output_file, subfolder)
    print(f"代码运行时间：{time.time() - start:.2f} 秒")
    print("Successful data Processing")

if __name__ == "__main__":
    file_files = ["lat.txt", "lon.txt", "height.txt", "Em.txt", "EmU.txt", "lst.txt", "lstE.txt", "qclst.txt"]
    combinelist(file_files, 'pll.txt', 'E:/Gu/MODIS/deal/txt')
    combinelist(['llheelll.txt'], 'plll', 'E:/Gu/MODIS/deal/txt')


def combine_all(folder_path, output_path=None):
    processor = DataProcessor()
    print(f"Starting to combine files in the folder: {folder_path}")
    file_count = 0  # To keep track of how many files have been processed
    for root, dirs, files in os.walk(folder_path):
        dirs[:] = []
        for file in files:
            if os.path.splitext(file)[1] == '.txt':
                #full_path = os.path.join(root, file)
                full_path = os.path.normpath(os.path.join(root, file))

                print(f"Combining file: {[full_path]} @#$%^&*!~*&^%$#@!~")
                all_band_list = processor.sample([full_path])  # save
                processor.save(all_band_list, output_path, full_path)
                file_count += 1
    if file_count == 0:
        print(f"No .txt files found in the folder: {folder_path}")
    else:
        print(f"Completed combining {file_count} files.")


def calculate_average(file1, file2, output_file):
    with open(file1, 'r') as f1, open(file2, 'r') as f2, open(output_file, 'w') as out:
        # 读取两个文件的每一行
        lines1 = f1.readlines()
        lines2 = f2.readlines()
        
        # 确保两个文件的行数相同
        if len(lines1) != len(lines2):
            print("文件行数不一致！")
            return
        
        # 逐行计算平均值并写入输出文件
        for line1, line2 in zip(lines1, lines2):
            avg = (float(line1.strip()) + float(line2.strip())) / 2
            out.write(f"{avg:.3f}\n")  # 保留三位小数
        print("平均值已写入输出文件。")
if __name__ == "__main__":
    # 定义文件路径
    file1 = 'file1.txt'  # 第一个文件路径
    file2 = 'file2.txt'  # 第二个文件路径
    output_file = 'averaged_output.txt'  # 输出文件路径

    # 调用函数进行计算
    calculate_average(file1, file2, output_file)


if __name__ == "__main__":
    combine_all('E:\Gu\MODIS\test', 'E:\Gu\MODIS\test')

class batchFun:#带子目录的批处理
    def __init__(self, path):
        self.path = path

    def list(self):
        for root, dirs, files in os.walk(self.path):
            print(files)

    def batch(self, function, *args, **kwargs):
        for root, dirs, files in os.walk(self.path):
            for file in files:
                if file.endswith('.txt'):
                    file = os.path.join(root, file)
                    print('---------------------------------------------')
                    print(f"Processing file: {file}")
                    function(file, *args, **kwargs)
                    print('---------------------------------------------')
        print('批处理完成')

class BatchFun:
    def __init__(self, path):
        self.path = path

    def list(self):
        # 列出当前目录下的所有文件和文件夹
        print(os.listdir(self.path))

    def batch(self, function, *args, **kwargs):
        # 遍历当前目录下的所有文件
        for file in os.listdir(self.path):
            file_path = os.path.join(self.path, file)
            # 检查是否为文件以及是否以.txt结尾
            if os.path.isfile(file_path) and file.endswith('.txt'):
                print('---------------------------------------------')
                print(f"Processing file: {file_path}")
                function(file_path, *args, **kwargs)
                print('---------------------------------------------')
        print('批处理完成')

def generate_lat_lon_columns(hdr_path):
    with open(hdr_path, 'r') as f:
        lines = f.readlines()

    metadata = {}
    for line in lines:
        if '=' in line:
            key, value = line.split('=', 1)
            metadata[key.strip()] = value.strip()

    # 提取必要信息
    samples = int(metadata['samples'])
    lines = int(metadata['lines'])
    map_info = metadata['map info'].strip('{}').split(',')
    left_top_lon = float(map_info[3])
    left_top_lat = float(map_info[4])
    lon_res = float(map_info[5])
    lat_res = float(map_info[6])

    # 创建经纬度矩阵
    lon_matrix = np.zeros((lines, samples))
    lat_matrix = np.zeros((lines, samples))

    # 填充经纬度矩阵
    for i in range(lines):
        for j in range(samples):
            lon_matrix[i, j] = left_top_lon + j * lon_res
            lat_matrix[i, j] = left_top_lat - i * lat_res

    # 展开为两列
    lon_column = lon_matrix.flatten()
    lat_column = lat_matrix.flatten()

    return lon_column, lat_column


def generate_lat_lon(hdr_path, file_path, output_dir):
    df = pd.read_csv(file_path, sep='\s+', comment=';', header=None).values  # 优化此行

    lon_column, lat_column = generate_lat_lon_columns(hdr_path)

    results = np.hstack((df, lon_column.reshape(-1, 1), lat_column.reshape(-1, 1)))  # 优化此行


    np.savetxt(output_dir, results, delimiter='\t', fmt='%.3f')
    print(f'结果已保存至: {output_dir}')


if __name__ == "__main__":
    generate_lat_lon('data\\rmodis\\230808.HDR', 'data\\rmodis\\rc230808.txt', 'data\\rmodis\\lrc230808.txt')
    generate_lat_lon('data\\rmodis\\230809.HDR', 'data\\rmodis\\rc230809.txt', 'data\\rmodis\\lrc230809.txt')