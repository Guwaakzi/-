import os
import re
import h5py
import time
from tqdm import tqdm
import numpy as np
import pandas as pd
import tensorflow as tf
#import autokeras as ak
from collections import namedtuple
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.models import clone_model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.losses import MeanSquaredError
from sklearn.metrics import  r2_score, mean_absolute_error, mean_squared_error
from sklearnex import patch_sklearn, unpatch_sklearn
from tensorflow.keras import layers, models
from tensorflow.keras.layers import Input, Dense, LSTM, Reshape, MultiHeadAttention, Lambda, Concatenate, Masking, Flatten
from tensorflow.keras.models import Model
import tensorflow as tf
from filterpy.kalman import KalmanFilter
from sklearn.model_selection import KFold
from colorama import Fore, Style
import matplotlib.pyplot as plt
from algorithms.mathM import Plot, Estopping, ReduceLR
#os.environ['TF_XLA_FLAGS'] = '--tf_xla_cpu_global_jit'
patch_sklearn()
#tf.config.optimizer.set_jit(True)

def calculate_mask(errors, value=1):
    errors = np.ravel(errors)
    initial_sd = np.std(errors)
    print(f"Test initial_SD: {initial_sd}\n")
    threshold = np.sqrt(value) * initial_sd
    judgment_diff = np.abs(errors) - threshold
    prob_keep = np.ones_like(errors)
    prob_keep[judgment_diff >= 0] = np.exp(-judgment_diff[judgment_diff >= 0] / threshold)
    mask = np.random.rand(len(errors)) < prob_keep

    num_true = np.sum(mask)
    num_false = len(mask) - num_true
    print(f"Number of True in mask: {num_true}")
    print(f"Number of False in mask: {num_false}")
    print(f"保留比为{num_true / len(mask)}")
    return mask



class AttentionLayer(layers.Layer):
    def __init__(self, units, **kwargs):
        super(AttentionLayer, self).__init__(**kwargs)
        self.units = units  # 注意这一行
        self.W1 = layers.Dense(units)
        self.W2 = layers.Dense(units)
        self.V = layers.Dense(1)

    def call(self, features):
        score = tf.nn.tanh(self.W1(features) + self.W2(features))
        attention_weights = tf.nn.softmax(self.V(score), axis=1)
        context_vector = attention_weights * features
        context_vector = tf.reduce_sum(context_vector, axis=1)
        context_vector = tf.expand_dims(context_vector, axis=-1)  # Expand dimensions
        return context_vector

    def get_config(self):
        config = super().get_config()
        config.update({
            'units': self.units,
        })
        return config






class KalmanFilterLayer():#Layer):
    def __init__(self, **kwargs):
        super(KalmanFilterLayer, self).__init__(**kwargs)
    
    def build(self, input_shape):
        # 初始化卡尔曼滤波器的参数，可以根据需要添加更多参数
        self.F = self.add_weight(shape=(1, 1), initializer="ones", trainable=True)
        self.H = self.add_weight(shape=(1, 1), initializer="ones", trainable=True)
        self.Q = self.add_weight(shape=(1, 1), initializer="ones", trainable=True)
        self.R = self.add_weight(shape=(1, 1), initializer="ones", trainable=True)
        self.x = self.add_weight(shape=(1, 1), initializer="zeros", trainable=True)
        self.P = self.add_weight(shape=(1, 1), initializer="ones", trainable=True)
        super(KalmanFilterLayer, self).build(input_shape)

    def call(self, inputs, *args, **kwargs):
        y_pred, y_true = inputs  # 假设输入是预测值和真实值
        corrected_preds = np.zeros_like(y_pred)

        for i, (yt, yp) in enumerate(zip(y_true, y_pred)):
            # 应用卡尔曼滤波算法
            # 预测步骤
            self.x = tf.matmul(self.F, self.x)
            self.P = self.F * self.P * tf.transpose(self.F) + self.Q

            # 更新步骤
            S = tf.matmul(self.H, self.P * tf.transpose(self.H)) + self.R
            K = tf.matmul(self.P * tf.transpose(self.H), tf.linalg.inv(S))
            self.x += K * (yt - tf.matmul(self.H, self.x))
            self.P = (1 - K * self.H) * self.P

            corrected_preds[i] = yp + self.x.numpy()[0, 0]
        
        return corrected_preds

    def compute_output_shape(self, input_shape):
        return input_shape
class KalmanFilterLayer(tf.keras.layers.Layer):
    def __init__(self, state_dim=64, **kwargs):
        super(KalmanFilterLayer, self).__init__(**kwargs)
        self.state_dim = state_dim
        self.transition_matrices = tf.eye(self.state_dim)
        self.observation_matrices = tf.eye(self.state_dim)
        self.initial_state_mean = tf.zeros((self.state_dim, 1))  # 注意形状为 [state_dim, 1]
        self.initial_state_covariance = tf.eye(self.state_dim)
        self.observation_covariance = tf.eye(self.state_dim) * 0.1
        self.transition_covariance = tf.eye(self.state_dim) * 0.01

    def call(self, inputs):
        state_estimate = self.initial_state_mean
        estimate_covariance = self.initial_state_covariance

        def filter_step(previous, current):
            prev_state_estimate, prev_estimate_covariance = previous
            observation = tf.reshape(current, (self.state_dim, 1))  # 确保观测值是列向量

            predicted_state_estimate = tf.matmul(self.transition_matrices, prev_state_estimate)
            predicted_estimate_covariance = tf.matmul(self.transition_matrices,
                                                      tf.matmul(prev_estimate_covariance, self.transition_matrices,
                                                                transpose_b=True)) + self.transition_covariance

            innovation = observation - tf.matmul(self.observation_matrices, predicted_state_estimate)
            innovation_covariance = tf.matmul(self.observation_matrices,
                                              tf.matmul(predicted_estimate_covariance, self.observation_matrices,
                                                        transpose_b=True)) + self.observation_covariance
            kalman_gain = tf.matmul(predicted_estimate_covariance,
                                    tf.matmul(self.observation_matrices, tf.linalg.inv(innovation_covariance),
                                              transpose_a=True))

            updated_state_estimate = predicted_state_estimate + tf.matmul(kalman_gain, innovation)
            updated_estimate_covariance = (tf.eye(self.state_dim) - tf.matmul(kalman_gain,
                                                                              self.observation_matrices)) @ predicted_estimate_covariance

            return (updated_state_estimate, updated_estimate_covariance)

        outputs, _ = tf.scan(filter_step, inputs, initializer=(state_estimate, estimate_covariance))
        #return tf.squeeze(outputs[-1])  # 可能需要调整以匹配输出形状的期望

        outputs = tf.reshape(outputs, (-1, self.state_dim))  # 调整KalmanFilterLayer的输出形状
        return outputs

    def compute_output_shape(self, input_shape):
        return (input_shape[0], self.state_dim)

class ExpandDimsLayer(tf.keras.layers.Layer):
    def __init__(self, axis=1, **kwargs):
        super().__init__(**kwargs)
        self.axis = axis

    def call(self, inputs):
        return tf.expand_dims(inputs, axis=self.axis)

class NNBuilder:

    def __init__(self, input_shape, output_units, layer_configs):
        self.input_shape = input_shape
        self.output_units = output_units
        self.layer_configs = layer_configs
        self.kalman = any(l.get('type') == 'KalmanFilter' for l in layer_configs)


    def apply_layers(self, x, configs):
        """Helper function to add layers to an input tensor."""
        for config in configs:
            layer_type = config.get('type', 'Dense')
            num_units = config.get('units')
            activation_fn = config.get('activation', None)
            if layer_type == 'Dense':
                x = tf.keras.layers.Dense(num_units, activation=activation_fn, kernel_initializer='he_normal')(x)
            elif layer_type in ['SimpleRNN', 'LSTM']:
                x = globals()[layer_type](num_units, activation=activation_fn, return_sequences=True)(x)
            elif layer_type == 'Attention' or layer_type == 'SelfAttention':
                num_heads = config.get('num_heads', 2)
                key_dim = config.get('key_dim')
                x = Lambda(lambda t: tf.where(tf.equal(t, -1), tf.zeros_like(t), t))(x)
                x = MultiHeadAttention(num_heads=num_heads, key_dim=key_dim)(x, x)
            elif layer_type == 'KalmanFilter':
                pass
        return x

    def build(self):
        input_layer = tf.keras.layers.Input(shape=self.input_shape)
        input = Lambda(lambda x: x[:, None, :])(input_layer)

        # Flatten the output if the last layer isn't naturally reducing dimensions
        processed = self.apply_layers(input, self.layer_configs)
        if len(processed.shape) != 2:
            processed = Flatten()(processed)


        final_output = tf.keras.layers.Dense(self.output_units, activation='linear')(processed)
        model = tf.keras.Model(inputs=input_layer, outputs=final_output)
        model.kalman = self.kalman
        return model
    
    def apply_kalman_filter(self, y_test, y_pred):

        kf = KalmanFilter(dim_x=1, dim_z=1)
        kf.F = np.array([[1.]])  # 状态转移矩阵
        kf.H = np.array([[1.]])  # 观测矩阵
        kf.R = 1/np.std(y_pred - y_test)          # 观测噪声
        if kf.R > 100:
            kf.R = kf.R / 100
        kf.Q =  1/r2_score(y_test, y_pred)       # 过程噪声
        kf.x = np.array([[0.]])  # 初始状态
        kf.P = np.array([[1.]])  # 初始协方差
        
        corrected_preds = np.zeros_like(y_pred)
        for i, (yt, yp) in enumerate(zip(y_test, y_pred)):
            kf.predict()
            kf.update(np.array([[yt - yp]]))
            corrected_preds[i] = yp + kf.x[0, 0] 
        corrected_preds = pd.Series(corrected_preds, index=y_pred.index)
    
        return corrected_preds


class Network:
    def __init__(self, model_dir):
        self.plot = Plot()
        self.load = Load()
        self.model_dir = model_dir
        # 确保模型目录存在
        if not os.path.exists(self.model_dir):
            os.makedirs(self.model_dir)
        self.model = None
        self.history = None

    def predict_data(self, model, X_test, y_true):
        y_pred = model.predict(X_test)
        if getattr(model, 'kalman', False):  
            print("Applying Kalman filter...")
            y_pred = Save.apply_kalman(y_true, y_pred)
        return y_pred


    def train(self, file_path, layer_configs, input, out, mask=None):

        df = pd.read_csv(file_path, sep='\s+', comment=';')
        X = df.iloc[:, input].values    #修改
        y = df.iloc[:, out].values   #修改

        scaler_X = StandardScaler()
        scaler_y = StandardScaler()
        X_ = scaler_X.fit_transform(X)
        y_ = scaler_y.fit_transform(y)

        X_train, X_test, y_train, y_test = train_test_split(X_, y_, test_size=0.15)
        print(f'Training file is: {file_path}')
        print(f'X_tr: {X_train.shape}, y_tr: {y_train.shape}, X_te: {X_test.shape}, y_te: {y_test.shape}')
        y_pred = self.train_int(layer_configs, X_train, X_test, y_train, y_test)

        save_path = os.path.join(f'{self.model_dir}', f'{os.path.splitext(os.path.basename(file_path))[0]}')
        self.model.save(f'{save_path}.h5')
        Save.save_metrics(f'{save_path}.h5', scaler_X, scaler_y)
        y_test = scaler_y.inverse_transform(y_test)
        y_pred = scaler_y.inverse_transform(y_pred)

        if mask:
            errors = y_test - y_pred
            mask = calculate_mask(errors)
            y_test = y_test[mask]
            y_pred = y_pred[mask]

        Save.accurate(y_test, y_pred)

        #label = {5: 'LSE31', 6: 'LSE32', 7: 'LST(K)'}.get(out[0], None)
        label = {5: 'LST(K)', 6: 'LSE10', 7: 'LSE11', 8: 'LSE12', 9: 'LSE13', 10: 'LSE14'}.get(out[0], None)
        fig1 = self.plot.analyze_and_plot(y_test.ravel(), y_pred.ravel(), label) # 真实值 vs. 预测值散点图
        fig2 = self.plot.plot_residuals(y_test, y_pred, 'file_name') # 残差图
        fig3 = self.plot.plot_loss_curve(self.history, 'file_name')  # 损失曲线   
        for fig, name in zip([fig1, fig2, fig3], ['scatter', 'residuals', 'loss']):
            fig_path = os.path.join(f'{self.model_dir}', f'{os.path.splitext(os.path.basename(file_path))[0]}_{label}_{name}.png')
            fig.savefig(fig_path)

        results = np.hstack((y_test, y_pred))  # 结果为 6 列
        np.savetxt(f'{save_path}_test.txt', results, delimiter='\t', fmt='%.3f')
        print(f"图片和数据保存到 {save_path}_test.txt 文件。")

    def train_int(self, layer_configs, X_train, X_test, y_train, y_test):
        self.model = NNBuilder(input_shape=(X_train.shape[1],), output_units=y_train.shape[1],layer_configs=layer_configs).build()
        self.model.summary()#显示层数
        optimizer = Adam(learning_rate=0.001)
        self.model.compile(optimizer, loss='mse')

        early_stop = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True, min_delta=0.0001,)
        reduce_lr = ReduceLROnPlateau(monitor="val_loss", patience=3)
        self.history = self.model.fit(X_train, y_train, epochs=30, batch_size=32, callbacks=[early_stop, reduce_lr], validation_split=0.15)

        #y_pred = model.predict(X_test)
        y_pred = self.predict_data(self.model, X_test, y_test)

        return y_pred

    def cross_validate(self, file, layer_configs, input, out, value, kf5=5):
        print(f'mask value is {value}')
        df = pd.read_csv(file, sep='\s+', comment=';', header=None)
        X = df.iloc[:, input].values    #修改
        y = df.iloc[:, out].values 
        scaler_X = StandardScaler()
        scaler_y = StandardScaler()
        X_ = scaler_X.fit_transform(X)
        y_ = scaler_y.fit_transform(y)
        kf = KFold(n_splits=kf5, shuffle=False)
        pr_li = []

        for fold, (tr_df, te_df) in enumerate(kf.split(X_), 1):
            print(Fore.CYAN + Style.BRIGHT + f"-------- ( Fold is {fold} ) --------" + Style.RESET_ALL)
            X_tr, X_te = X_[tr_df], X_[te_df]
            y_tr, y_te = y_[tr_df], y_[te_df]
            y_pr_ = self.train_int(layer_configs, X_tr,  X_te, y_tr, y_te)
            pr_li.append(y_pr_)


        y_pr = np.vstack(pr_li)
        y_pr = scaler_y.inverse_transform(y_pr)
        y_pr = pd.DataFrame(y_pr)

        df_new = pd.concat([df, y_pr], axis=1)
        y_te = df_new.iloc[:, out].values
        y_pr = df_new.iloc[:, [out[0] + 2]].values
        errors = y_te - y_pr
        print(f"the shape of errors is {errors.shape}")

        mask = calculate_mask(errors, value)

        filtered_y_test = y_te[mask]
        filtered_y_pred = y_pr[mask]
        #fig1 = self.plot.analyze_and_plot(filtered_y_test, filtered_y_pred, 'label') # 真实值 vs. 预测值散点图
        #fig_path = os.path.join('result', f'{self.model_dir}', f'{os.path.splitext(os.path.basename(file))[0]}.png')
        #fig1.savefig(fig_path)

        filtered_df_new = df_new[mask]
        file_path = os.path.join(f'{self.model_dir}', f'{os.path.splitext(os.path.basename(file))[0]}.txt')
        filtered_df_new.to_csv(file_path, sep='\t', index=False, header=False)

        print(f"Number of data points before filtering: {len(y_te)}")
        print(f"Number of data points after filtering: {len(filtered_y_test)}")

        Save.accurate(filtered_y_test, filtered_y_pred)

    def predict(self, model_path, file_path, input, out):

        pload = Load()
        model = pload.load_model(model_path)
        X_, y_true  = pload.load_data(file_path, input, out)
        pred = model.predict(X_)
        y_pred = pload.scaler_y.inverse_transform(pred)
        print(f'shape of y_true is {y_true.shape}')
        print(f'shape of y_pred is {y_pred.shape}')
        Save.accurate(y_true, y_pred)

        results = np.hstack((y_true, y_pred))  # 结果为 6 列
        # 保存为 txt 文件，以制表符 '\t' 分隔

        save_path = os.path.join(f'{self.model_dir}', f'predict_{os.path.splitext(os.path.basename(file_path))[0]}')
        np.savetxt(f'{save_path}.txt', results, delimiter='\t', fmt='%.3f')
        label = {5: 'LSE31', 6: 'LSE32', 7: 'LST(K)'}.get(out[0], None)
        fig1 = self.plot.analyze_and_plot(y_true.ravel(), y_pred.ravel(), label) # 真实值 vs. 预测值散点图
        fig1.savefig(f'{save_path}_{label}_scatter.png')
        print(f"图片和数据已保存到 {save_path}.txt 文件。")
        return y_pred


# example usage
if __name__ == "__main__":
    layer = [{'Dense': 64, 'activation': 'relu', 'dropout': 0.25},]
    Network('c9').predict('result\\c9\\rdrc230809.h5', 'result\\data\\drc230809.txt', [0,1,2,3,4], 7)
    Network('test').train('data\modis\cn1w.txt', layer,  [0,1,2,3,4], [7])
    Network('test').cross_validate('data\modis\cn1w.txt', layer,  [0,1,2,3,4,6], [7], 1, 2)



class Load:
    def __init__(self):
        self.scaler_X = StandardScaler()
        self.scaler_y = StandardScaler()
        self.model = None

    def extract_lon_lat(self, first_line_comment):
        lon, lat = None, None
        match = re.search(r"'samples': (\d+), 'lines': (\d+)", first_line_comment)
        if match:
            samples = int(match.group(1))
            lines = int(match.group(2))
            lon = samples
            lat = lines
        return lon, lat

    def load_model(self, model_path):
        self.model = tf.keras.models.load_model(model_path, custom_objects={'mse': MeanSquaredError()})
        with h5py.File(model_path, 'r') as f:
            grp = f['metrics_parameters']
            self.scaler_X.mean_ = np.array(grp['X_mean'])
            self.scaler_X.scale_ = np.array(grp['X_std'])
            self.scaler_y.mean_ = np.array(grp['y_mean'])
            self.scaler_y.scale_ = np.array(grp['y_std'])
        return self.model

    def load_data(self, file_path, input, out, model_path=None):
        df = pd.read_csv(file_path, sep='\s+', comment=';', header=None)
        X = df.iloc[:, input].values             
        y = df.iloc[:, out].values   
        if model_path is not None:
            self.load_model(model_path)
            print('已加载模型配置参数')
            y = self.scaler_y.transform(y)
        X_ = self.scaler_X.transform(X)
        return X_, y.reshape(-1, 1)

class Save:
    def __init__(self):
        self.plot = Plot()
        #pass

    @staticmethod
    def save_metrics(save_path, scaler_X, scaler_y):#Save normalization parameters
        with h5py.File(save_path, 'a') as f:
            f.flush()
            print("File opened successfully and flushed")

            grp = f.create_group('metrics_parameters')

            grp.create_dataset('X_mean', data=scaler_X.mean_)
            grp.create_dataset('X_std', data=scaler_X.scale_)

            grp.create_dataset('y_mean', data=scaler_y.mean_)
            grp.create_dataset('y_std', data=scaler_y.scale_)

            print("Successfully added model information")

    @staticmethod
    def accurate(y_test, y_pred):
        pccs = np.corrcoef(y_test.flatten(), y_pred.flatten())[0, 1]
        r2 = r2_score(y_test, y_pred)
        mae = mean_absolute_error(y_test, y_pred)
        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        bias = np.mean(y_pred - y_test)
        sd = np.std(y_pred - y_test)
        print(f'Test   pcc: {pccs}')
        print(f'Test  (R^2): {r2}')
        print(f'Test    mae: {mae}')
        print(f'Test   rmse: {rmse}')
        print(f"Test   BIAS: {bias}")
        print(f"Test     SD: {sd}\n")

    @staticmethod
    def apply_kalman(y_test, y_pred):

        kf = KalmanFilter(dim_x=1, dim_z=1)
        kf.F = np.array([[1.]])  # 状态转移矩阵
        kf.H = np.array([[1.]])  # 观测矩阵
        kf.R = 1/np.std(y_pred - y_test)          # 观测噪声
        if kf.R > 100:
            kf.R = kf.R / 100
        kf.Q =  1/r2_score(y_test, y_pred)       # 过程噪声
        kf.x = np.array([[0.]])  # 初始状态
        kf.P = np.array([[1.]])  # 初始协方差
        
        corrected_preds = np.zeros_like(y_pred)
        for i, (yt, yp) in enumerate(zip(y_test, y_pred)):
            kf.predict()
            kf.update(np.array([[yt.item() - yp.item()]]))
            corrected_preds[i] = yp + kf.x[0, 0] 
        corrected_preds = np.array(corrected_preds)
    
        return corrected_preds 

    def model_save(self, model, info):
        file_path, y_test, y_test_pred, scaler_X, scaler_y, history = info
        save_path = os.path.join('model', 'kd',
                             f"{os.path.splitext(os.path.basename(file_path))[0]}.h5")
        model.save(save_path)
        Save.save_metrics(save_path, scaler_X, scaler_y)
        y_test = scaler_y.inverse_transform(y_test)
        y_test_pred = scaler_y.inverse_transform(y_test_pred)
        file_name = os.path.splitext(os.path.basename(save_path))[0]
        fig1 = self.plot.plot_true_vs_predicted(y_test, y_test_pred, file_name)  # 真实值 vs. 预测值散点图
        fig2 = self.plot.plot_residuals(y_test, y_test_pred, file_name)  # 残差图
        tig3 = self.plot.plot_loss_curve(history, file_name)  # 损失曲线

layer = [
    {'type': 'Dense', 'units': 128, 'activation': 'relu'},
    {'type': 'Dense', 'units': 64, 'activation': 'relu'},
    {'type': 'Dense', 'units': 64, 'activation': 'relu'},
    {'type': 'Dense', 'units': 32, 'activation': 'relu'},
]
class Kdtune:
    def __init__(self, model_dir):
        self.mse_loss = MeanSquaredError()
        self.optimizer = Adam(learning_rate=0.001)
        self.plot = Plot()
        self.kload = Load()
        self.model = None
        self.model_dir = model_dir
        if not os.path.exists(self.model_dir):
            os.makedirs(self.model_dir)

    #@tf.function
    def distillation_loss(self, y, y_s, pseudo_labels):
        y = tf.cast(y, tf.float32)
        loss_student = self.mse_loss(y_s, y)
        loss_teacher = self.mse_loss(y_s, pseudo_labels)
        loss = self.alpha * loss_teacher + (1 - self.alpha) * loss_student
        return loss

    @tf.function
    def train_step(self, sub_model, X_batch, y_true_batch, pseudo_labels_batch):
        with tf.GradientTape() as tape:
            y_pred_batch = sub_model(X_batch, training=True)
            loss_value = self.distillation_loss(y_true_batch, y_pred_batch, pseudo_labels_batch)
        grads = tape.gradient(loss_value, sub_model.trainable_variables)
        self.optimizer.apply_gradients(zip(grads, sub_model.trainable_variables))
        return loss_value

    def tuner(self, all_model_path, file_path, input, out, alpha=None, index=None):
        self.alpha = alpha
        epochs = 30
        batch_size = 32  # Set your batch size
        history = []
        epoch_losses = {}
        epoch_weights = {}
        early_stopping = Estopping(min_delta=0.0001)
        reduce_lr = ReduceLR(self.optimizer)

        X_, y_= self.kload.load_data(file_path, input, out, all_model_path)  # 加载数据,模型
        pseudo_labels_ = self.kload.model.predict(X_)
        X_true, X_test, y_true, y_test, pseudo_labels, pseudo_labels_test = train_test_split(X_, y_, pseudo_labels_, test_size=0.2, random_state=42)
        X_train, X_val, y_train, y_val, pseudo_labels_train, pseudo_labels_val = train_test_split(X_true, y_true, pseudo_labels, test_size=0.2, random_state=42)


        #sub_model = NNBuilder(input_shape=(X_train.shape[1],), output_units=y_train.shape[1],layer_configs=layer).build()
  
        sub_model = clone_model(self.kload.model)
        #sub_model.set_weights(all_model.get_weights())
        sub_model.compile(optimizer=self.optimizer, loss=self.mse_loss)
        sub_model.summary()
        num_batches = len(X_train) // batch_size

        for epoch in range(epochs):
            total_train_loss = 0
            total_time = 0
            idx = np.arange(len(X_train))
            np.random.shuffle(idx)

            custom_bar_format = "{desc} {n_fmt}/{total_fmt} [{bar:30}] {percentage:3.0f}% [{elapsed}<{remaining}, {rate_fmt}{postfix}]"
            with tqdm(total=num_batches, desc=f"Epoch {epoch + 1}/{epochs}", bar_format=custom_bar_format, unit="batch",ascii=".>=", ) as pbar:
                pbar.set_postfix(epoch=epoch + 1, epochs=epochs, refresh=True)
                for batch_num in range(num_batches):
                    batch_idx = idx[batch_num * batch_size: (batch_num + 1) * batch_size]
                    X_batch = X_train[batch_idx]
                    y_batch = y_train[batch_idx]
                    pseudo_labels_batch = pseudo_labels_train[batch_idx] # Dynamically generate pseudo labels for this batch
                    train_loss = self.train_step(sub_model, X_batch, y_batch, pseudo_labels_batch)#核心程式

                    total_train_loss += train_loss.numpy()  # 累计当前批次的损失
                    pbar.update(1)
                    pbar.set_postfix({"loss": f"{total_train_loss / (batch_num + 1):.4f}"})

                avg_train_loss = total_train_loss / num_batches
                #val_loss = self.train_step(sub_model, X_val, y_val, pseudo_labels_val)
                y_val_pred = sub_model(X_val, training=False)
                val_loss = self.mse_loss(y_val_pred, y_val)
                #val_loss = self.distillation_loss(y_val, y_val_pred, pseudo_labels_val)
                current_lr = float(reduce_lr.on_epoch_end(epoch, val_loss, patience=3))  # 确保转换为 Python float
                pbar.set_postfix({"loss": f"{avg_train_loss:.4f}", "val_loss": f"{val_loss:.4f}", "lr": f"{current_lr:.6f}"})

                history.append((avg_train_loss, val_loss))

                if early_stopping.on_epoch_end(epoch, val_loss, patience=5):
                    print(f"Early stopping at epoch {epoch}")
                    break

            # 保存每个epoch的平均损失
            epoch_losses[epoch] = val_loss
            # 保存当前epoch的模型权重到内存
            epoch_weights[epoch] = sub_model.get_weights()

        # 早停逻辑触发后
        best_epoch = min(epoch_losses, key=epoch_losses.get)
        print(f"Best epoch is {best_epoch} with val_loss {epoch_losses[best_epoch]}")
        best_weights = epoch_weights[best_epoch]          # 从内存加载最佳模型的权重
        sub_model.set_weights(best_weights)

        y_test_pred = sub_model.predict(X_test)
        y_test_pred = self.kload.scaler_y.inverse_transform(y_test_pred)

        y_test1 = pseudo_labels_test * alpha + y_test * (1 - alpha)
        y_test1 = self.kload.scaler_y.inverse_transform(y_test1)


        #y_test1 = y_test1.ravel()
        #y_test_pred = y_test_pred.ravel()
        print(f'shape of y_true is {y_test1.shape}')
        print(f'shape of y_pred is {y_test_pred.shape}')
        #y_test_pred = Save.apply_kalman(y_test1, y_test_pred)
        Save.accurate(y_test1, y_test_pred)

        if index is None:

            save_path = os.path.join(f'{self.model_dir}', f'{os.path.splitext(os.path.basename(file_path))[0]}')
            sub_model.save(f'{save_path}_KD.h5')
            Save.save_metrics(f'{save_path}_KD.h5', self.kload.scaler_X, self.kload.scaler_y)


            label = {5: 'LSE31', 6: 'LSE32', 7: 'LST(K)'}.get(out[0], None)
            fig1 = self.plot.analyze_and_plot(y_test1.ravel(), y_test_pred.ravel(), label) # 真实值 vs. 预测值散点图
            fig2 = self.plot.plot_residuals(y_test1, y_test_pred, 'file_name') # 残差图
            fig3 = self.plot.plot_loss_curve(history, 'file_name')  # 损失曲线   
            for fig, name in zip([fig1, fig2, fig3], ['scatter', 'residuals', 'loss']):
                fig_path = os.path.join(f'{self.model_dir}', f'{os.path.splitext(os.path.basename(file_path))[0]}_{label}_{name}_KD.png')
                fig.savefig(fig_path)

            results = np.hstack((y_test1, y_test_pred))  
            np.savetxt(f'{save_path}_test_KD.txt', results, delimiter='\t', fmt='%.3f')
            print(f"图片和数据保存到 {save_path}_KD.txt 文件。")



class ModelPredictor:
    def __init__(self):
        #self.scaler_X = StandardScaler()
        #self.scaler_y = StandardScaler()

        self.plot = Plot()
        self.load = Load()
        self.model = None
        self.scaler_X = self.load.scaler_X
        self.scaler_y = self.load.scaler_y


    def predict(self, model_path, file_path, out):
        model = self.load.load_model(model_path)

        X_features, y_targets ,_,_, lat, lon = self.load.load_data(file_path, out)



        predictions = model.predict(X_features)
        y_pred = self.scaler_y.inverse_transform(predictions)

        '''data = pd.read_csv(file_path, header=None)  # Add 'header=None' if the file has no header
        data['New_Column'] = y_pred  # Append y_pred as a new column
        data.to_csv(file_path, index=False, header=False)  # Write back to the file'''


        y_targets = self.scaler_y.inverse_transform(y_targets)

        X_features = self.scaler_X.inverse_transform(X_features)
        rows_with_zero = np.any(X_features == 0, axis=1)
        y_pred[rows_with_zero] = 0

        with open('output.txt', 'w') as file:
            for target, pred in zip(y_targets, y_pred):
                file.write(f"{target[0]}\t{pred[0]}\n")
        file_name, file_extension = os.path.splitext(file_path.split('/')[-1])


        yline = pd.DataFrame({
            'y_targets': y_targets.flatten(),  # 使用 flatten() 确保数据是一维的
            'y_pred': y_pred.flatten()
        })
        yline = yline[~(yline == 0).any(axis=1) & ~(yline == 200).any(axis=1)]

        # 将 yline 的列重新塑形为 (n, 1) 的数组
        y_pred_d = yline['y_pred'].values.reshape(-1, 1)
        y_targets_d = yline['y_targets'].values.reshape(-1, 1)

        # 打印新的形状以确认
        print("Projected results reshaped:", y_pred_d.shape)
        print("Targets results reshaped:", y_targets_d.shape)
        print("Projected results:", y_pred_d.shape)
        print("Targets results:", y_targets_d.shape)

        RMSE = np.sqrt(np.mean((y_pred_d - y_targets_d) ** 2))
        mae = mean_absolute_error(y_pred_d, y_targets_d)
        pccs = np.corrcoef(y_targets_d.flatten(), y_pred_d.flatten())[0, 1]
        r2 = r2_score(y_pred_d, y_targets_d)
        print(f' Predict Loss of RMSE: {RMSE}')
        print(f' Predict Pearson Correlation: {pccs}')
        print(f'Predict Loss of mae  : {mae}')

        #self.plot.plot_temperature_maps(y_targets, y_pred, lat, lon, file_name)
        #self.plot.plot_true_vs_predicted_(y_targets_d, y_pred_d, file_name)  # 真实值 vs. 预测值散点图
        lim = None
        if out in [10, 5  -1]:
            lim = 298
        elif out in [6, 7, 8]:
            lim = 0.74
        elif out in [9, 10]:
            lim = 0.85
        #self.plot.analyze_and_plot(y_targets_d, y_pred_d, lim)
        fig = self.plot.analyze_and_plot_(y_targets_d, y_pred_d, mae, pccs, r2, 'lst')
        fig_path = os.path.join('png', f'pre_{os.path.splitext(os.path.basename(file_path))[0]}_.png')  # 构建文件路径
        fig.savefig(fig_path)  # 保存fig1对象到文件
        #self.plot.plot_residuals(y_targets, y_pred, file_name)
        return y_pred, y_targets

def predict(model_path, file_path, out):
    print(f'predict is {model_path} to {file_path}')
    predictor = ModelPredictor()
    prediction, y_targets = predictor.predict(model_path, file_path, out)
    print('                                                      8 ')


# example usage
if __name__ == "__main__":
    predict('data/sub_data.h5', 'data/test_data.txt')



import logging
from datetime import datetime
logging.basicConfig(filename='tuning_log.log', level=logging.INFO)
class Itertune:
    def __init__(self):
        #self.kd = Kdtune()
        self.Save = Save()

    def itertune(self, trials, super_model_path, file_path, sub_model_path=None):

        ex_n = 0
        ex_pccs = 0
        best_alpha = None
        best_mae = None
        best_model = None  # 用于存储最佳模型的变量
        best_info = None
        logging.info(f'{datetime.now()}-------------------itertune----------------------------------')

        for i in range(trials):
            print(f'the{i}')
            in_pccs = 0  # 将 in_pccs 重置为0以开始新的内部循环
            in_n = 0  # 将 in_n 重置为0以开始新的内部循环

            for alpha in np.arange(0, 1.1, 0.1):
                alpha = round(alpha, 1)
                print(f'tune with {alpha} in {i}')
                kd = Kdtune()
                model, info = kd.tuner(super_model_path, file_path, sub_model_path, alpha)
                loss, pccs_, r2, mae = info.loss, info.pccs, info.r2, info.mae  # 获取模型和pccs值

                if pccs_ > in_pccs:
                    print(f'pccs_:{pccs_}>in_pccs:{in_pccs},Precision Improvement')
                    in_pccs = pccs_
                    in_n += 1
                    best_alpha = alpha
                    best_mae = mae
                    best_model = model  # 更新最佳模型
                    best_info = info
                    logging.info(f'{datetime.now()}, Alpha: {alpha}, PCCS: {pccs_}, MAE: {mae}, Upgraded: {in_n} times')
                else:
                    print(f'Upgraded {in_n} times now')
                    print(f'pccs_:{pccs_}<=in_pccs:{in_pccs},Not saved')

            if in_pccs > ex_pccs:
                print(f'in_pccs:{in_pccs}>ex_pccs:{ex_pccs},Precision Improvement')
                self.Save.model_save(best_model, best_info)  # 保存最佳模型
                ex_n += 1
                logging.info(f'{datetime.now()}, BestAlpha: {best_alpha}, PCCS: {in_pccs}, MAE: {best_mae}, saved: {ex_n} times')
                ex_pccs = in_pccs
                print(f'saved {ex_n} times now')
            else:
                print(f'saved {ex_n} times now')
                print(f'in_pccs:{in_pccs}<=ex_pccs:{ex_pccs},Not saved')

        print(f'Total upgraded {ex_n} times')

    def selftune(self, trials, super_model_path, file_path, sub_model_path):
        alpha = 0
        n = 0
        pccs = 0
        mae = 0
        logging.info(f'{datetime.now()}-----------------------selftune------------------------------')
        for i in range(trials):
            kd = Kdtune()
            print(f'the{i}')
            model, info = kd.tuner(super_model_path, file_path, sub_model_path, alpha)
            loss, pccs_, r2 = info.loss, info.pccs, info.r2
            if pccs_ > pccs:
                print(f'{pccs_}>{pccs},saved')
                print(f'Upgraded {n} times now')
                self.Save.model_save(model, info)
                pccs = pccs_
                n = n + 1
                logging.info(f'{datetime.now()},PCCS: {pccs}, MAE: {mae}, Upgraded: {n} times')

            else:
                print(f'Upgraded {n} times now')
                print(f'{pccs_}<={pccs},Not saved')

        print(f'Total upgraded {n} times')








if __name__ == "__main__":
    tune('data/sub_data.h5', 'data/sub_data.txt','data/sub_data.h5' )

unpatch_sklearn()
