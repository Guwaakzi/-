import h5py
import os
import numpy as np
import pandas as pd
from filterpy.kalman import KalmanFilter
#from algorithms.mathM import Plot
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from matplotlib import ticker
from matplotlib.font_manager import FontProperties
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde
from tqdm import tqdm
import torch
from matplotlib.colors import Normalize
from PIL import Image
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
#device = torch.device("cpu")
print(f"Using device: {device}")

def batch_crop(folder_path):
    count = 0  # 初始化图片计数器
    for root, dirs, files in os.walk(folder_path):
        for name in files:
            if name.startswith('gass') and name.lower().endswith('.png'):
                image_path = os.path.join(root, name)
                crop_image(image_path)
                print(f'Processed image: {image_path}')
                count += 1  # 每处理一个文件，计数器加1
    print(f'Total images processed: {count}')  # 打印总处理图片数量

def batch_ploot(folder_path):
    count = 0  # 初始化txt文件计数器
    for root, dirs, files in os.walk(folder_path):
        for name in files:
            if name.lower().endswith('.txt'):  # 只处理txt文件
                txt_path = os.path.join(root, name)  # 获取txt文件的完整路径
                # 获取父目录的名称
                parent_dir = os.path.basename(os.path.dirname(txt_path))
                # 提取parent_dir中"_"后面的部分作为label
                if "_" in parent_dir:
                    label = parent_dir.split("_", 1)[1]
                else:
                    label = "unknown"  # 如果没有"_"，设置默认label
                
                # 调用ploot函数处理文件
                ploot(txt_path, label)
                print(f'Processed txt: {txt_path} with label: {label}')  # 打印处理信息
                count += 1  # 每处理一个文件，计数器加1
    print(f'Total txt files processed: {count}')  # 打印总处理txt文件数量


def crop_image(image_path):

    img = Image.open(image_path)


    # 显示原始图片的像素大小
    print(f'原始图片大小: {img.size}')

    # 定义裁剪区域，左上角为（0，40），右下角为（565，480）
    crop_area = (0, 40, 575, 480)
    cropped_img = img.crop(crop_area)

    # 保存图片，包括父目录名称在文件名中
    save_path = 'result_1/png'
    os.makedirs(save_path, exist_ok=True)
    parent_dir = os.path.basename(os.path.dirname(image_path))
    file_name = f"{parent_dir}_{os.path.basename(image_path)}"
    cropped_img.save(os.path.join(save_path, file_name))

def analyze_and_plot_(x, y, label, mode='normal', lmax=1):
    fig, ax = plt.subplots()  # 使用 plt.subplots() 创建新的 Figure 和 Axes
    pccs = np.corrcoef(x, y)[0, 1]
    r2 = r2_score(x, y)
    mae = mean_absolute_error(x, y)
    x = np.round(x * 1000 / 2) * 2 / 1000


    font = FontProperties(family='Times New Roman', size=15)

    # 定义格式化函数，用于确保标签的精度
    def custom_formatter(val, pos):
        return f'{val:.3f}'.rstrip('0').rstrip('.')
    def gaussian_kde_tqdm(x, y):
        xy = np.vstack([x, y])
        kde = gaussian_kde(xy)

        # 初始化一个空的数组用于存储结果
        z = np.zeros(xy.shape[1])
        # 使用 tqdm 显示进度条
        for i in tqdm(range(xy.shape[1]), desc="Calculating KDE"):
            z[i] = kde(xy[:, i])
        return z
    def gaussian_kde_gpu(x, y, bandwidth=0.1):
        # 将数据转换为 GPU 上的张量
        xy = torch.tensor(np.vstack([x, y]), device=device)

        # 初始化结果张量
        z = torch.zeros(xy.shape[1], device=device)

        # 使用 GPU 计算高斯核密度估计
        for i in tqdm(range(xy.shape[1]), desc="Calculating KDE on GPU"):
            # 计算每个点的密度值
            diff = xy - xy[:, i].unsqueeze(1)
            kernel = torch.exp(-0.5 * torch.sum(diff**2, dim=0) / bandwidth**2)
            z[i] = kernel.mean()
        
        return z.cpu().numpy()



    

    x = x.round(3)  # 或者使用 y_true.flatten()
    y = y.round(3) # 或者使用 y_pred.flatten()


    # Visualization
    mae_format = f"{mae:.2e}" if mae < 0.01 else f"{mae:.3f}"
    ax.xaxis.set_major_locator(ticker.MaxNLocator(5))
    ax.yaxis.set_major_locator(ticker.MaxNLocator(5))

    axis_limits = {
        'LST(K)': {'xlim': (295, lmax), 'ylim': (295, lmax)},
        'LSE10': {'xlim': (0.74, 1), 'ylim': (0.74, 1)},
        'LSE11': {'xlim': (0.74, 1), 'ylim': (0.74, 1)},
        'LSE12': {'xlim': (0.74, 1), 'ylim': (0.74, 1)},
        'LSE13': {'xlim': (0.85, 1), 'ylim': (0.85, 1)},
        'LSE14': {'xlim': (0.85, 1), 'ylim': (0.85, 1)}
    }
    limits = axis_limits.get(label)
    ax.set_xlim(left=limits['xlim'][0], right=limits['xlim'][1])
    ax.set_ylim(bottom=limits['ylim'][0], top=limits['ylim'][1])



    # if label == 'LST(K)':
    #     ax.set_xlim(left=255, right=345)
    #     ax.set_ylim(bottom=255, top=345)
    # elif label == 'LSE32':
    #     ax.set_xlim(left=0.96, right=1)    
    #     ax.set_ylim(bottom=0.96, top=1)

    # elif label == 'LSE31':  
    #     ax.set_xlim(left=0.95, right=1)    
    #     ax.set_ylim(bottom=0.95, top=1)
    #     ax.xaxis.set_major_locator(ticker.MaxNLocator(6))
    #     ax.yaxis.set_major_locator(ticker.MaxNLocator(6))
        #ax.xaxis.set_major_locator(ticker.FixedLocator([0.95, 0.9625, 0.975, 0.9875, 1.0]))
        #ax.yaxis.set_major_locator(ticker.FixedLocator([0.95, 0.9625, 0.975, 0.9875, 1.0]))
    if mode == 'ribbon':
        z= gaussian_kde_gpu(x, y)
        idx = z.argsort()
        x, y, z = x[idx], y[idx], z[idx]
        norm = Normalize(vmin=z.min(), vmax=z.max())
        scatter = ax.scatter(x, y, marker='o', c=norm(z), edgecolors=None, s=30, alpha=0.8, cmap='RdBu_r') #RdBu_r,Purples
        cbar = plt.colorbar(scatter, ax=ax, shrink=1, orientation='vertical', extend='both', pad=0.015, aspect=30)
        cbar.ax.set_yticklabels([])
        cbar.ax.set_yticks([])

        cbar.set_label('Relative Density', fontproperties=font)
        tick_locs = np.linspace(0, 1, num=5)
        cbar.set_ticks(tick_locs)
        cbar.set_ticklabels([f'{val:.1f}' for val in tick_locs])
    else:
        ax.scatter(x, y, edgecolors=None, s=30, alpha=0.8)

    # Regression calculations
    k, b = np.polyfit(x, y, 1)
    std_err = np.std(y - (k * x + b))
    margin_of_error = 1.96 * (std_err / np.sqrt(1))
    regression_line = k * x + b
    lower_confidence_bound = k * x + b - margin_of_error
    upper_confidence_bound = k * x + b + margin_of_error

    ax.plot(x, regression_line, 'violet', lw=1.5, label='Reg Line', alpha=0.6)
    ax.plot(x, lower_confidence_bound, linestyle='--', color='orange', dashes=(4, 16), label='95% Band', lw=1.5, alpha=0.8)
    ax.plot(x, upper_confidence_bound, linestyle='--', color='orange', dashes=(4, 16), alpha=0.8, lw=1.5)
    ax.plot([y.min(), y.max()], [y.min(), y.max()], 'red', lw=1.5, linestyle='--', label='1:1 Line')
    ax.text(0.60, 0.16, f'MAE ={mae_format}', fontproperties=font, transform=ax.transAxes, verticalalignment='top',)
    ax.text(0.59, 0.08, f'PCC={pccs:.3f}', fontproperties=font, transform=ax.transAxes, verticalalignment='top')
    ax.text(0.61, 0.24, f'R^2={r2:.3f}', fontproperties=font, transform=ax.transAxes, verticalalignment='top')


    x_ticks = ax.get_xticks()
    y_ticks = ax.get_yticks()
    ax.xaxis.set_major_locator(ticker.FixedLocator(x_ticks))
    ax.yaxis.set_major_locator(ticker.FixedLocator(y_ticks))  

    # 设置自定义格式化的标签
    ax.set_xticklabels([custom_formatter(tick, None) for tick in x_ticks], fontproperties=font)
    ax.set_yticklabels([custom_formatter(tick, None) for tick in y_ticks], fontproperties=font)
    ax.set_xlabel(f'{label}', fontproperties=font)
    ax.set_ylabel(f'Retrieval {label}', fontproperties=font)


    ax.legend(loc='upper left', frameon=False, prop=font)
    ax.grid(True, linestyle='--', alpha=0.8)
    #plt.show()
    return fig


def ensure_directory(path):
    directory = os.path.dirname(path)
    if not os.path.exists(directory):
        os.makedirs(directory)



def kalman_filter(y_pred, y_true):
    kf = KalmanFilter(dim_x=1, dim_z=1)
    kf.F = np.array([[1.]])  # 状态转移矩阵
    kf.H = np.array([[1.]])  # 观测矩阵
    kf.R = 1/np.std(y_pred - y_true)          # 观测噪声
    if kf.R > 100:
        kf.R = kf.R / 100
    kf.Q =  1/r2_score(y_true, y_pred)       # 过程噪声
    kf.x = np.array([[0.]])  # 初始状态
    kf.P = np.array([[1.]])  # 初始协方差
    
    corrected_preds = np.zeros_like(y_pred)
    for i, (yt, yp) in enumerate(zip(y_true, y_pred)):
        kf.predict()
        kf.update(np.array([[yt - yp]]))
        corrected_preds[i] = yp + kf.x[0, 0] 
    corrected_preds = pd.Series(corrected_preds, index=y_pred.index)

    return corrected_preds



def filter_errors(file_path, mode):
    df = pd.read_csv(file_path, sep='\s+', comment=';')
    y_test = df.iloc[: ,0] # 第一列是真实值
    y_pred = df.iloc[: ,1] # 第二列是预测值

    y_pred = kalman_filter(y_pred, y_test, )

    pccs = np.corrcoef(y_test, y_pred)[0, 1]
    r2 = r2_score(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    bias = np.mean(y_pred - y_test)
    sd = np.std(y_pred - y_test)

    print(f'show of {mode}')
    print(f'Test   pcc: {pccs}')
    print(f'Test  (R^2): {r2}')
    print(f'Test    mae: {mae}')
    print(f'Test   rmse: {rmse}')
    print(f"Test   BIAS: {bias}")
    print(f"Test     SD: {sd}\n")

    fig = Plot.analyze_and_plot_(y_test, y_pred, mode) # 真实值 vs. 预测值散点图
    #fig.show()

'''    fig_path = file_path[:file_path.rfind('\\') + 1] + f'Gchina7_{mode}_scatter.png'
    fig.savefig(fig_path)

    y_test_array = y_test.to_numpy().reshape(-1, 1)
    y_pred_array = y_pred.to_numpy().reshape(-1, 1)
    results = np.hstack((y_test_array, y_pred_array))

    new_file_path = file_path[:file_path.rfind('\\') + 1] + 'G' + file_path[file_path.rfind('\\') + 1:]
    np.savetxt(new_file_path, results, delimiter='\t', fmt='%.3f')'''


#filter_errors('result\Gcn7LSE1\china7_test.txt', 'LSE1')
#filter_errors('result\Gcn7LSE2\china7_test.txt', 'LSE2')
#filter_errors('result\Gcn7LST\china7_test.txt', 'LST')
#filter_errors('result\c6LST\drc230806_test.txt', 'mask')

def ploot(file_path, label, mode='ribbon'):
    df = pd.read_csv(file_path, sep='\s+', comment=';')
    y_test = df.iloc[: ,0] # 第一列是真实值
    y_pred = df.iloc[: ,1] # 第二列是预测值
    parent_dir = os.path.basename(os.path.dirname(file_path))
    if "a39" in parent_dir:
        lmax = 332
    else:
        lmax = 347
    fig = analyze_and_plot_(y_test, y_pred, label, mode, lmax) # 真实值 vs. 预测值散点图
    fig_path = os.path.join(os.path.dirname(file_path), f"gass_{os.path.basename(file_path)}.png")
    fig.savefig(fig_path)
    plt.close(fig)

if __name__ == "__main__":
    mode='ribbon'
    #mode='normal'
    ploot('result_1\cnGLSE31\china7_test.txt', 'LSE31', mode)
    ploot('result_1\cnGLSE32\china7_test.txt', 'LSE32', mode)
    ploot('result_1\cnGLST\china7_test.txt', 'LST(K)', mode)
    ploot('result_1\cnLSE31\china7_test.txt', 'LSE31', mode)
    ploot('result_1\cnLSE32\china7_test.txt', 'LSE32', mode)
    ploot('result_1\cnLST\china7_test.txt', 'LST(K)', mode)

    ploot('result_1\c8LSE31\drc230808_test.txt', 'LSE31', mode)
    ploot('result_1\c8LSE32\drc230808_test.txt', 'LSE32', mode)
    ploot('result_1\c8LST\drc230808_test.txt', 'LST(K)', mode)
    ploot('result_1\c9LSE31\drc230809_test.txt', 'LSE31', mode)
    ploot('result_1\c9LSE32\drc230809_test.txt', 'LSE32', mode)
    ploot('result_1\c9LST\drc230809_test.txt', 'LST(K)', mode)

    ploot('result_1\K8LSE31\drc230808_test_KD.txt', 'LSE31', mode)
    ploot('result_1\K8LSE32\drc230808_test_KD.txt', 'LSE32', mode)
    ploot('result_1\K8LST\drc230808_test_KD.txt', 'LST(K)', mode)
    ploot('result_1\K9LSE31\drc230809_test_KD.txt', 'LSE31', mode)
    ploot('result_1\K9LSE32\drc230809_test_KD.txt', 'LSE32', mode)
    ploot('result_1\K9LST\drc230809_test_KD.txt', 'LST(K)', mode)



