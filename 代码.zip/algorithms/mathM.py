import os
import matplotlib.pyplot as plt
from datetime import datetime
from scipy import stats
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error, explained_variance_score
from tensorflow.keras import regularizers, layers, models
import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.neighbors import KernelDensity
from scipy.stats import gaussian_kde
from tqdm import tqdm
from math import sqrt, pi
import time
import datetime
import chardet
from matplotlib import ticker
from matplotlib.font_manager import FontProperties
import torch
from matplotlib.colors import Normalize

class DataDel:
    @staticmethod
    def del_zero(file_path):
        output_file = os.path.join(os.path.dirname(file_path), "d" + os.path.basename(file_path))

        # 读取文本文件到 DataFrame
        #df.iloc[:, 17] = df.iloc[:, 17].astype(str)
        df = pd.read_csv(file_path, comment=';', header=None, sep='\t', dtype={17: str})

        # 统计每列0值的数量
        c_llh = df[df.iloc[:, 0] == 0].shape[0]
        c_em = df[df.iloc[:, 3] == 0].shape[0]
        c_lst = df[df.iloc[:, 15] == 0].shape[0]

        # 删除含有0值的行
        df = df[(df.iloc[:, 0] != 0) & (df.iloc[:, 3] != 0) & (df.iloc[:, 15] != 0)]

        # 输出信息
        print(f"Number of rows with 0 in the first column: {c_llh}")
        print(f"Number of rows with 0 in the fourth column: {c_em}")
        print(f"Number of rows with 0 in the sixteenth column: {c_lst}")
        print(f"Number of rows after processing: {df.shape[0]}")

        # 保存处理后的数据
        df.to_csv(output_file, index=False, header=False, sep='\t')

    @staticmethod
    def dell(file_path):
        output_file = os.path.join(os.path.dirname(file_path), "d" + os.path.basename(file_path))

        # 读取文本文件到 DataFrame
        df = pd.read_csv(file_path, comment=';', header=None, sep='\t', dtype={17: str})
        all = df.shape[0]

        # 统计每列0值的数量
        c_llh = df.iloc[:, 0] != 0
        n = 1
        c_em1 = ((286 - n) <= df.iloc[:, 3]) & (df.iloc[:, 3] <= (321 + n))
        c_em2 = ((282 - n) <= df.iloc[:, 4]) & (df.iloc[:, 4] <= (314 + n))
        c_em3 = ((279 - n) <= df.iloc[:, 5]) & (df.iloc[:, 5] <= (310 + n))
        c_em4 = ((271 - n) <= df.iloc[:, 6]) & (df.iloc[:, 6] <= (302 + n))
        c_em5 = ((274 - n) <= df.iloc[:, 7]) & (df.iloc[:, 7] <= (304 + n))
        c_em6 = ((274 - n) <= df.iloc[:, 8]) & (df.iloc[:, 8] <= (303 + n))
        c_lst = ((274 - n) <= df.iloc[:, 15])

        # 分析每个十进制数值出现的次数
        # df['decimal'] = df.iloc[:, 17].apply(lambda x: int(x, 2))
        # value_counts = df['decimal'].value_counts()
        # value_counts.to_csv(output_file, sep='\t', index=True, header=False)

        # 输出信息

        print('............................................')
        print(f"Number of rows with 0 in the  llh : {all - c_llh.shape[0]}")
        print('............................................')
        print(f"Number of rows deleted due to em 1: {all - df[c_em1].shape[0]}")
        print(f"Number of rows deleted due to em 2: {all - df[c_em2].shape[0]}")
        print(f"Number of rows deleted due to em 3: {all - df[c_em3].shape[0]}")
        print(f"Number of rows deleted due to em 4: {all - df[c_em4].shape[0]}")
        print(f"Number of rows deleted due to em 5: {all - df[c_em5].shape[0]}")
        print(f"Number of rows deleted due to em 6: {all - df[c_em6].shape[0]}")
        print(f"Number of rows deleted due to lst : {all - df[c_lst].shape[0]}")

        # 删除含有0值的行
        df = df[c_em1 & c_em2 & c_em3 & c_em4 & c_em5 & c_em6 & c_lst]
        # 保存处理后的数据
        df.to_csv(output_file, index=False, header=False, sep='\t')

        print(f"Number of rows before processing: {all}")
        print(f"Number of rows after  processing: {df.shape[0]}")

    @staticmethod
    def del_anyzero(file_path):
        output_file = os.path.join(os.path.dirname(file_path), "d" + os.path.basename(file_path))

        # 读取文本文件到 DataFrame
        df = pd.read_csv(file_path, comment=';', header=None, sep='\t')

        # 删除含有0值的行
        rows_before = df.shape[0]
        #df = df[~(df == 0).any(axis=1) & ~(df.iloc[:, 5] == 200)]  # 删除任意一列为零的行
        df = df[~(df == 0).any(axis=1) & (df.iloc[:, 5] > 300) & (df.iloc[:, 6] < 1) & (df.iloc[:, 7] < 1) & (df.iloc[:, 8] < 1) & (df.iloc[:, 9] < 1) & (df.iloc[:, 10] < 1)]

        rows_after = df.shape[0]

        # 输出信息
        print(f"Number of rows before processing: {rows_before}")
        print(f"Number of rows after processing: {rows_after},and del:{rows_before - rows_after}")

        # 保存处理后的数据
        df.to_csv(output_file, index=False, header=False, sep='\t')

    @staticmethod
    def shushu(file_path):

        df = pd.read_csv(file_path, comment=';', header=None, sep='\t')
        n = 1

        c1 = df[(n < df.iloc[:, 6])]
        c2 = df[(n < df.iloc[:, 7])]
        c3 = df[(n < df.iloc[:, 8])]
        c4 = df[(n < df.iloc[:, 9])]
        c5 = df[(n < df.iloc[:, 10])]

        print(f'c1 is {c1.shape[0]}')
        print(f'c2 is {c2.shape[0]}')
        print(f'c3 is {c3.shape[0]}')
        print(f'c4 is {c4.shape[0]}')
        print(f'c5 is {c5.shape[0]}')



    @staticmethod
    def concat(file_list, name):
        # 读取所有文件并将它们合并为一个DataFrame
        dfs = [pd.read_csv(file, sep="\t", header=None) for file in file_list]
        final_data = pd.concat(dfs, ignore_index=True)

        # 构造输出文件路径并保存合并后的数据
        processed_file_path = os.path.join(os.path.dirname(file_list[0]), name)
        final_data.to_csv(processed_file_path, sep='\t', index=False, header=False)


if __name__ == "__main__":
    DataDel.dell('E:/Gu/MODIS/deal/txt/drcll.txt')

if __name__ == "__main__":
    DataDel.del_zero('E:/Gu/MODIS/deal/txt/rcll.txt')

if __name__ == "__main__":
    files_to_concat = ['/path/to/file1.txt', '/path/to/file2.txt', '/path/to/file3.txt']  # 可以是任意数量的文件
    DataDel.concat(files_to_concat, 'concat.txt')


class DataProcessor:
    def read_file(self, file_path):
        '''with open(file_path, 'rb') as f:
            rawdata = f.read()
        result = chardet.detect(rawdata)
        charenc = result['encoding']
        with open(file_path, 'r', encoding=charenc) as f:
            file_content = f.read()'''
        with open(file_path, 'r') as f:
            file_content = f.read()
        return file_content

    def save(self, band_list, output_path, subfolder):
        output_file = os.path.join(subfolder, "combine", "c" + os.path.basename(output_path))
        flattened_data_list = []
        for band in band_list:
            for data in band:
                flattened_data = []
                for row in data:
                    flattened_data.extend(row)
                flattened_data_list.append(flattened_data)
        total_rows = len(flattened_data_list[0])
        total_columns = len(band_list)

        with open(output_file, 'w') as f:
            # Write Python-readable comments about the dimensions and generation time
            original_dimensions = f"; Original_Dimensions = {{'samples': {len(band_list[0][0])}, 'lines': {len(band_list[0])}}}\n"
            new_dimensions = f"; New_Dimensions = {{'samples': {total_columns}, 'lines': {total_rows}}}\n"
            generated_time = f"; Generated_Time = '{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}'\n"
            f.write(original_dimensions)
            f.write(new_dimensions)
            f.write(generated_time)

            # Write the flattened and combined data
            format = "{desc} {n_fmt}/{total_fmt} [{bar:30}] {percentage:3.0f}% [{elapsed}<{remaining}, {rate_fmt}{postfix}]"
            for rows in tqdm(zip(*flattened_data_list), desc="Processing Rows", total=len(flattened_data_list[0]),
                             bar_format=format, unit="batch", ascii=".>="):
                combined_row = "\t".join(rows)
                f.write(combined_row + "\n")
        print(f"The file has been saved at: {output_file}")

    def sample(self, file_list):
        all_band_list = []
        format = "{desc} {n_fmt}/{total_fmt} [{bar:30}] {percentage:3.0f}% [{elapsed}<{remaining}, {rate_fmt}{postfix}]"
        for file in tqdm(file_list, desc='Processing file', bar_format=format, unit="batch", ascii=".>="):
            file_content = self.read_file(file)
            file_lines = file_content.strip().split("\n")
            band_data_list = []
            current_band = []
            for line in file_lines:
                line = line.strip()
                if line.startswith(";") or not line:  # Skip comments and empty lines
                    # If we encounter an empty line, it means a new band is starting
                    if not line and current_band:
                        band_data_list.append(current_band)
                        current_band = []
                    continue
                # line_data = list(map(float, line.split()))
                line_data = line.split()
                current_band.append(line_data)
            if current_band:
                band_data_list.append(current_band)
            all_band_list.append(band_data_list)
        return all_band_list

def combinelist(file_list, output_file, subfolder):
    file_list = [f"{subfolder}/{file}" for file in file_list]
    output_file = f"{subfolder}/{output_file}.txt"
    processor = DataProcessor()
    start = time.time()
    all_band_list = processor.sample(file_list)  # save
    processor.save(all_band_list, output_file, subfolder)
    print(f"代码运行时间：{time.time() - start:.2f} 秒")
    print("Successful data Processing")

if __name__ == "__main__":
    file_files = ["lat.txt", "lon.txt", "height.txt", "Em.txt", "EmU.txt", "lst.txt", "lstE.txt", "qclst.txt"]
    combinelist(file_files, 'pll.txt', 'E:/Gu/MODIS/deal/txt')
    combinelist(['llheelll.txt'], 'plll', 'E:/Gu/MODIS/deal/txt')


def combine_all(folder_path, output_path=None):
    processor = DataProcessor()
    print(f"Starting to combine files in the folder: {folder_path}")
    file_count = 0  # To keep track of how many files have been processed
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if os.path.splitext(file)[1] == '.txt':
                #full_path = os.path.join(root, file)
                full_path = os.path.normpath(os.path.join(root, file))

                print(f"Combining file: {full_path}")
                processor.sample(full_path, output_path)
                #combine(full_path, output_path)
                file_count += 1
    if file_count == 0:
        print(f"No .txt files found in the folder: {folder_path}")
    else:
        print(f"Completed combining {file_count} files.")

if __name__ == "__main__":
    combine_all('E:\Gu\MODIS\test', 'E:\Gu\MODIS\test')


class Plot:

    @staticmethod
    def analyze_and_plot(x, y, label, mode='normal'):
        fig, ax = plt.subplots()  # 使用 plt.subplots() 创建新的 Figure 和 Axes
        pccs = np.corrcoef(x, y)[0, 1]
        r2 = r2_score(x, y)
        mae = mean_absolute_error(x, y)

        font = FontProperties(family='Times New Roman', size=15)

        # 定义格式化函数，用于确保标签的精度
        def custom_formatter(val, pos):
            return f'{val:.3f}'.rstrip('0').rstrip('.')
        def gaussian_kde_tqdm(x, y):
            xy = np.vstack([x, y])
            kde = gaussian_kde(xy)
            # 初始化一个空的数组用于存储结果
            z = np.zeros(xy.shape[1])
            # 使用 tqdm 显示进度条
            for i in tqdm(range(xy.shape[1]), desc="Calculating KDE"):
                z[i] = kde(xy[:, i])
            return z
        def gaussian_kde_gpu(x, y, bandwidth=0.1, device='cpu'):
            xy = torch.tensor(np.vstack([x, y]), device=device)
            z = torch.zeros(xy.shape[1], device=device)
            # 使用 GPU 计算高斯核密度估计
            for i in tqdm(range(xy.shape[1]), desc="Calculating KDE on GPU"):
                # 计算每个点的密度值
                diff = xy - xy[:, i].unsqueeze(1)
                kernel = torch.exp(-0.5 * torch.sum(diff**2, dim=0) / bandwidth**2)
                z[i] = kernel.mean()
            return z.cpu().numpy()

        # Visualization
        mae_format = f"{mae:.2e}" if mae < 0.01 else f"{mae:.3f}"

        if mae < 0.01:
            ax.set_xlim(left=0.955, right=1)  # 设置x轴的最小值为0.965
            ax.set_ylim(bottom=0.955, top=1)  # 设置y轴的最小值为0.965
        else:
            ax.set_xlim(left=255, right=345)  # 设置x轴的最小值为260
            ax.set_ylim(bottom=255, top=345)  # 设置y轴的最小值为260
        if mode == 'ribbon':
            #z = gaussian_kde(xy)(xy)
            z= gaussian_kde_gpu(x, y)
            idx = z.argsort()
            x, y, z = x[idx], y[idx], z[idx]
            norm = Normalize(vmin=z.min(), vmax=z.max())
            scatter = ax.scatter(x, y, marker='o', c=norm(z), edgecolors=None, s=30, alpha=0.8, cmap='Purples') #RdBu_r
            cbar = plt.colorbar(scatter, ax=ax, shrink=1, orientation='vertical', extend='both', pad=0.015, aspect=30)
            cbar.ax.set_yticklabels([])
            cbar.ax.set_yticks([])

            cbar.set_label('Relative Density', fontproperties=font)
            tick_locs = np.linspace(0, 1, num=5)
            cbar.set_ticks(tick_locs)
            cbar.set_ticklabels([f'{val:.1f}' for val in tick_locs])
        else:
            ax.scatter(x, y, edgecolors=None, s=30, alpha=0.8)

        # Regression calculations
        k, b = np.polyfit(x, y, 1)
        std_err = np.std(y - (k * x + b))
        margin_of_error = 1.96 * (std_err / np.sqrt(1))
        regression_line = k * x + b
        lower_confidence_bound = k * x + b - margin_of_error
        upper_confidence_bound = k * x + b + margin_of_error

        ax.plot(x, regression_line, 'violet', lw=1.5, label='Reg Line', alpha=0.6)
        ax.plot(x, lower_confidence_bound, linestyle='--', color='orange', dashes=(4, 16), label='95% Band', lw=1.5, alpha=0.8)
        ax.plot(x, upper_confidence_bound, linestyle='--', color='orange', dashes=(4, 16), alpha=0.8, lw=1.5)
        ax.plot([y.min(), y.max()], [y.min(), y.max()], 'red', lw=1.5, linestyle='--', label='1:1 Line')
        ax.text(0.60, 0.16, f'MAE ={mae_format}', fontproperties=font, transform=ax.transAxes, verticalalignment='top',)
        ax.text(0.59, 0.08, f'PCC={pccs:.3f}', fontproperties=font, transform=ax.transAxes, verticalalignment='top')
        ax.text(0.61, 0.24, f'R^2={r2:.3f}', fontproperties=font, transform=ax.transAxes, verticalalignment='top')

        ax.xaxis.set_major_locator(ticker.MaxNLocator(5))  #
        ax.yaxis.set_major_locator(ticker.MaxNLocator(5))  # 
        x_ticks = ax.get_xticks()
        y_ticks = ax.get_yticks()
        ax.xaxis.set_major_locator(ticker.FixedLocator(x_ticks))
        ax.yaxis.set_major_locator(ticker.FixedLocator(y_ticks))  

        # 设置自定义格式化的标签
        ax.set_xticklabels([custom_formatter(tick, None) for tick in x_ticks], fontproperties=font)
        ax.set_yticklabels([custom_formatter(tick, None) for tick in y_ticks], fontproperties=font)
        ax.set_xlabel(f'{label}', fontproperties=font)
        ax.set_ylabel(f'Retrieval {label}', fontproperties=font)


        ax.legend(loc='upper left', frameon=False, prop=font)
        ax.grid(True, linestyle='--', alpha=0.8)
        #plt.show()
        return fig

    @staticmethod
    def plot_true_vs_predicted(y_true, y_pred, file_name):
        fig, ax = plt.subplots()
        # Calculate the point densities using a Gaussian kernel density estimate
        y_true = y_true.ravel()  # 或者使用 y_true.flatten()
        y_pred = y_pred.ravel()  # 或者使用 y_pred.flatten()
        xy = np.vstack([y_true, y_pred])
        z = gaussian_kde(xy)(xy)

        # Create the scatter plot with density as the color, using circular markers and no edge colors
        scatter = ax.scatter(y_true, y_pred, c=z, s=50, edgecolor='None', marker='o', cmap='viridis', alpha=1)

        # Adding a color bar
        cbar = plt.colorbar(scatter, ax=ax)
        cbar.set_label('Density')

        # Add a line of best fit
        ax.plot([y_true.min(), y_true.max()], [y_true.min(), y_true.max()], 'k--', lw=2)
        # Set labels and title
        ax.set_xlabel('True Values')
        ax.set_ylabel('Predicted Values')
        ax.set_title(f'True vs. Predicted Values of {file_name}')
        # Grid and show
        ax.grid(True)
        plt.show()
        return fig



        # Testing the function with no edge colors

    @staticmethod
    def plot_true_vs_predicted_(y_true, y_pred, file_name):
        fig = plt.figure()
        plt.scatter(y_true, y_pred, alpha=0.5)
        plt.plot([y_true.min(), y_true.max()], [y_true.min(), y_true.max()], 'k--', lw=2)
        plt.xlabel('True Values')
        plt.ylabel('Predicted Values')
        plt.title(f'True vs. Predicted Values of {file_name}#')
        #plt.xlim(left=298)  # 设置 x 轴最小值为 300，最大值自动
        #plt.ylim(bottom=298)  # 设置 y 轴最小值为 300，最大值自动
        #plt.xlim(200, 330)
        #plt.ylim(200, 330)
        plt.grid(True)
        plt.show()


    @staticmethod
    def plot_residuals(y_true, y_pred, file_name):
        fig = plt.figure()
        residuals = y_true - y_pred
        plt.scatter(y_pred, residuals, alpha=0.5)
        plt.hlines(0, y_pred.min(), y_pred.max(), colors='k', linestyles='dashed')
        plt.xlabel('Predicted Values')
        plt.ylabel('Residuals')
        plt.title(f'Residual Plot of {file_name}')
        #plt.xlim(250, 330)
        #plt.ylim(-75, 25)
        plt.grid(True)
        #plt.show()
        return fig

    '''@staticmethod
    def plot_loss_curve(history, file_path):
        plt.plot(history.history['loss'], label='Train Loss')
        plt.plot(history.history['val_loss'], label='Validation Loss')
        plt.xlabel('Epochs')
        plt.ylabel('Loss')
        plt.title(f'Loss Curve of {file_path}')
        plt.legend()
        plt.grid(True)
        plt.show()'''

    @staticmethod
    def plot_loss_curve(history, file_name):
        fig = plt.figure()
        if hasattr(history, 'history'):
            plt.plot(history.history['loss'], label='Train Loss')
            plt.plot(history.history['val_loss'], label='Validation Loss')
        elif isinstance(history, list) and isinstance(history[0], tuple):
            # Separate the tuple into two lists: one for training loss and one for validation loss
            train_loss = [item[0] for item in history]
            val_loss = [item[1] for item in history]

            # Plotting
            plt.plot(train_loss, label='KD Train Loss')
            plt.plot(val_loss, label='KD Validation Loss')

        plt.xlabel('Epochs')
        plt.ylabel('Loss')
        plt.title(f'Loss Curve of {file_name}')
        plt.legend()
        plt.grid(True)
        #plt.show()
        return fig

    @staticmethod
    def plot_temperature_maps(y_test, y_pred, latitude, longitude, file_path):
        print("latitude, longitude", latitude, longitude)

        '''y_pred_nonzero = y_pred[y_pred != 0]
        vmin = y_pred_nonzero.min()
        vmax = y_pred_nonzero.max()'''
        '''y_test_nonzero = y_test[y_test != 0]
        y_pred_nonzero = y_pred[y_pred != 0]

        # 计算非零值的全局最小值和最大值
        vmin = min(y_test_nonzero.min(), y_pred_nonzero.min())
        vmax = max(y_test_nonzero.max(), y_pred_nonzero.max())'''

        def map_to_rgb(data):
            # 筛选出非零数据
            #data_nonzero = data[data != 0 & data != 200]
            data_nonzero = data[np.logical_and(data != 0, data != 200)]
            # 计算非零数据的最小值和最大值
            vmin, vmax = data_nonzero.min(), data_nonzero.max()
            vmin = 290
            vmax = 330
            print(f'vmin:{vmin}    vmax:{vmax}')

            # 归一化非零数据到0-1范围
            data_normalized = np.zeros_like(data, dtype=float)
            nonzero_indices = data != 0
            data_normalized[nonzero_indices] = (data[nonzero_indices] - vmin) / (vmax - vmin)

            # 创建RGB数组
            data_rgb = np.full((*data.shape, 3), 255, dtype=int)  # 初始化为全白色
            data_rgb[nonzero_indices, :] = (data_normalized[nonzero_indices, None] * 255).astype(int)

            return data_rgb

        def plot_single_map(ax, data, title):
            data_rgb = map_to_rgb(data.reshape(latitude, longitude))
            ax.imshow(data_rgb, interpolation='nearest')
            ax.set_title(f'{title} of {file_path}')
            ax.set_xlabel('Longitude')
            ax.set_ylabel('Latitude')

        fig = plt.figure(figsize=(14, 7))  # 调整总图的尺寸

        ax1 = fig.add_subplot(1, 2, 1)
        plot_single_map(ax1, y_test, 'Actual Surface Temperature')

        ax2 = fig.add_subplot(1, 2, 2)
        plot_single_map(ax2, y_pred, 'Predicted Surface Temperature')

        plt.tight_layout()
        plt.show()
        return fig

    # 示例调用
    # plot_temperature_maps(y_test, y_pred, latitude, longitude, file_path)

    '''@staticmethod
    def plot_temperature_maps(y_test, y_pred, latitude, longitude, file_path):
        print("latitude, longitude", latitude, longitude)


        fig = plt.figure()
        latitude_array = np.linspace(0, latitude, latitude + 1)
        longitude_array = np.linspace(0, longitude, longitude + 1)

        def plot_single_map(ax, data, title, vmin, vmax):
            # 将小于下限值的数据设置为白色
            data[data < vmin] = np.nan  # 小于vmin设为空
            data = np.flipud(data)  # 翻转数据
            c = ax.pcolormesh(longitude_array, latitude_array, data, shading='auto', cmap='hot', vmin=vmin, vmax=vmax)
            c.set_facecolor('white')  #空值设为白色
            plt.colorbar(c, ax=ax, label='Temperature (K)')
            # 获取当前轴的位置信息

            ax.set_title(f'{title} of {file_path}')
            ax.set_xlabel('Longitude')
            ax.set_ylabel('Latitude')
            ax.set_aspect(latitude/longitude)

        vmin, vmax = sorted(set(y_pred.ravel()))[1], max(y_test.max(), y_pred.max())
        vmin = vmin - 2
        vmax = vmax + 2
        print(vmin, vmax)

        width = 7  # 单个子图的宽度（单位：英寸）
        total_width =  2 * width  # 总宽度（单位：英寸），这里考虑了两个子图
        height = width * (latitude / longitude - 0.2)
        plt.figure(figsize=(total_width, height))
        #plt.figure(figsize=(15, 7))
        ax1 = plt.subplot(1, 2, 1)
        plot_single_map(ax1, y_test.reshape(latitude, longitude), 'Actual Surface Temperature', vmin, vmax)
        ax2 = plt.subplot(1, 2, 2)
        plot_single_map(ax2, y_pred.reshape(latitude, longitude), 'Predicted Surface Temperature', vmin, vmax)
        plt.tight_layout()
        plt.show()
        return fig'''



if __name__ == "__main__":
    Plot.plot_true_vs_predicted(y_test, y_test_pred, file_name)  # 真实值 vs. 预测值散点图
    Plot.plot_residuals(y_test, y_test_pred, file_name)  # 残差图
    Plot.plot_loss_curver(history, file_name)  # 损失曲线

class DataAnalyzer:
    def __init__(self, file_path, column_index, num_bins, relative):
        #self.biu = Transmit()
        self.file_path = file_path
        self.column_index = column_index
        self.num_bins = num_bins
        self.relative = relative
        self.control_points = []
        self.X_labels = []
        self.bin_labels = []
        self.percentage = []
        self.y_norm = []
        self.sigma = None
        self.mean = None
        self.mu = None
        self.max_x = None
        self.max_y = None

    def read_data(self):
        self.df = pd.read_csv(self.file_path, delim_whitespace=True, comment=';')
        X = self.df.iloc[:, :-1].values
        y = self.df.iloc[:, self.column_index].values.reshape(-1, 1)
        num_lines = len(self.df)
        min_value = y.min()
        max_value = y.max()

        bin_edges = np.linspace(min_value, max_value, self.num_bins + 1)
        hist, _ = np.histogram(self.df.iloc[:, self.column_index], bins=bin_edges)
        self.percentage = (hist / hist.sum()) * 100
        self.bin_labels = [f"{bin_edges[i]:.5f} - {bin_edges[i + 1]:.5f}" for i in range(len(bin_edges) - 1)]
        self.X_labels = ["{:.2f}".format((float(x.split(' - ')[0]) + float(x.split(' - ')[1])) / 2) for x in
                         self.bin_labels]

        # 找到最大的百分比和对应的区间标签
        #self.max_y = np.max(self.percentage)
        #self.max_x = self.X_labels[np.argmax(self.percentage)]
        #self.mean = np.mean(y)
        max_y = np.max(self.percentage)
        self.max_y = max_y
        max_x = self.X_labels[np.argmax(self.percentage)]
        self.max_x = max_x
        mean = np.mean(y)
        self.mean = mean
        self.sigma = np.std(y)
        self.sigma = np.std(y)
        #print(f"range:{min_value}, {max_value}")
        #print(f"x,y: {self.max_x},{self.max_y}")
        #print(f"mean: {self.mean}")
        #print("self.sigma", self.sigma)
        # print(f"sigma: {sigma}")
        #self.biu.to.pdf = mean
        return X, y, num_lines

    def balance_data(self, sampling_mode):
        # 1. Read the txt file
        x, y, num_lines = self.read_data()
        save_zip = list(zip(self.bin_labels, self.percentage, self.y_norm))
        new_rows = pd.DataFrame(columns=self.df.columns)
        total_added_rows = 0
        max_revise_count = 0
        max_true_count = 0
        for bin_label, true, revise in save_zip:
            true_count = round(true * num_lines)
            revise_count = round(revise * num_lines)
            if revise_count > max_revise_count:
                max_revise_count = revise_count
            if true_count > max_true_count:
                max_true_count = true_count

        print(f'max_revise_count：{max_revise_count},,,max_true_count:{max_true_count}')


        for bin_label, true, revise in save_zip:
            lower, upper = map(float, bin_label.split(' - '))
            true_count = round(true * num_lines)
            revise_count = round(revise * num_lines)

            #print(f'true_count:{true_count}-revise_count:{revise_count}')

            # 2. Retrieve rows that fall within the current bin
            bin_items = self.df[(y >= lower) & (y < upper)]

            if len(bin_items) == 0:
                continue

            # Initialize an empty DataFrame with the same columns as bin_items
            temp_rows = pd.DataFrame(columns=bin_items.columns)

            max_revise_count = round(max_true_count/4)

            if true_count < max_revise_count:
                print(f'      true_count:{true_count}')
                print(f'max_revise_count:{max_revise_count}')
                if sampling_mode == 'average':

                    # 3. Calculate quotient and residual
                    quotient = (max_revise_count - true_count) // true_count
                    residual = (max_revise_count - true_count) % true_count


                    if quotient > 0:
                        temp_rows = pd.concat([bin_items] * quotient, ignore_index=True)
                    if residual > 0:
                        residual = min(residual, len(bin_items))
                        residual_rows = bin_items.sample(n=residual)
                        temp_rows = pd.concat([temp_rows, residual_rows], ignore_index=True)

                    new_rows = pd.concat([new_rows, temp_rows], ignore_index=True)
                    total_added_rows += len(temp_rows)


            if true_count < revise_count:
                # 2. Retrieve rows that fall within the current bin
                #bin_items = self.df[(y >= lower) & (y < upper)]

                #if len(bin_items) == 0:
                #    continue

                # 3. Calculate quotient and residual
                quotient = (revise_count - true_count) // true_count
                residual = (revise_count - true_count) % true_count

                # Initialize an empty DataFrame with the same columns as bin_items
                #temp_rows = pd.DataFrame(columns=bin_items.columns)

                # 4. Copy 'quotient' times, if quotient is not zero
                if sampling_mode == "full":
                    if quotient > 0:
                        temp_rows = pd.concat([bin_items] * quotient, ignore_index=True)
                    if residual > 0:
                        residual = min(residual, len(bin_items))
                        residual_rows = bin_items.sample(n=residual)
                        temp_rows = pd.concat([temp_rows, residual_rows], ignore_index=True)

                # 5. Partial sampling: Pick 'true * (revise - true) / revise' number of rows
                elif sampling_mode == "partial":
                    partial_count = round(true_count  / revise_count )* (revise_count - true_count)
                    if partial_count > 0:
                        partial_count = min(partial_count, len(bin_items))
                        partial_rows = bin_items.sample(n=partial_count)
                        temp_rows = pd.concat([temp_rows, partial_rows], ignore_index=True)

                # 6. Residual sampling: Pick 'residual' number of rows only
                elif sampling_mode == "residual":
                    if residual > 0:
                        residual = min(residual, len(bin_items))
                        residual_rows = bin_items.sample(n=residual)
                        temp_rows = pd.concat([temp_rows, residual_rows], ignore_index=True)

                # 6. Add the new rows to the DataFrame
                new_rows = pd.concat([new_rows, temp_rows], ignore_index=True)
                total_added_rows += len(temp_rows)
        print(f"Total number of rows added: {total_added_rows}")

        # 7. Randomly insert new rows into the original DataFrame and save to new txt file
        df = pd.concat([self.df, new_rows], ignore_index=True)
        df = df.sample(frac=1).reset_index(drop=True)  # Shuffle the DataFrame
        output_path = os.path.join(os.path.dirname(self.file_path), f"N{self.relative}_{sampling_mode}_{os.path.basename(self.file_path)}")
        df.to_csv(output_path, sep='\t', index=False)
        return output_path

    def gaussian(self):
        X_labels = self.X_labels
        if self.relative is True:
            mean = float(self.max_x)
        elif self.relative is False:
            #mean = self.biu.me.pdf
            mean = self.mean
        #max_x, max_y, mean = self.biu.me.pdf
        max_x = self.max_x
        max_y = self.max_y
        sigma = self.sigma
        #mean = float(self.max_x)
        #max_x, max_y, sigma = self.max_y, self.max_y, self.sigma

        self.mu = mean

        x_norm = np.array([float(x) for x in X_labels])
        x_norm.min(), x_norm.max()
        self.y_norm = max_y * norm.pdf(x_norm, mean, sigma) / norm.pdf(float(max_x), mean, sigma)

        x_scp = [mean - 3 * sigma, mean - 2 * sigma, mean - sigma, mean + sigma, mean + 2 * sigma, mean + 3 * sigma]
        x_scp = [x for x in x_scp if x >= x_norm.min() and x <= x_norm.max()]
        x_cp = [x_norm[np.argmin(np.abs(x_norm - point))] for point in x_scp]
        y_cp = max_y * norm.pdf(x_cp, mean, sigma) / norm.pdf(float(max_x), mean, sigma)
        y_tp = [self.percentage[np.argmin(np.abs(x_norm - point))] for point in x_cp]

        self.control_points = list(zip(x_cp, y_cp, y_tp))  # Standard Control Point, Control Point, True Control Point
        print("percentile_points", self.control_points)
        # self.save()
        return self.y_norm, max_x, max_y

    def g(self, n):
        x = np.array([float(i) for i in self.X_labels])  # 将字符串转换为浮点数，并确保 x 是一个 NumPy 数组
        sigma = self.sigma
        mu = self.mu
        # = sqrt(2) * n * exp(-((x - mu) ** 2) / (2 * (n * sigma) ** 2))
        term1 = np.sqrt(2) * n * np.exp(-((x - mu) ** 2) / (2 * (n * sigma) ** 2))

        term2 = 2 * sqrt(pi) * sqrt((n * sigma) ** 2)
        result = term1 / term2
        result_np = np.array(result)

        # 将结果转换回字符串列表
        # result_str_list = [str(i) for i in result]
        return result_np

    def plot_data(self):
        tick = round(self.num_bins / 10)
        self.read_data()
        X_labels = self.X_labels
        percentage = self.percentage
        y_norm, max_x, max_y = self.gaussian()

        fig, ax = plt.subplots(figsize=(12, 6))
        ax.bar(X_labels, percentage, color='b', alpha=0.6, label='Percentage (%)')
        ax.plot(X_labels, percentage, color='r', label='Percentage (Line)')
        ax.plot(X_labels, y_norm, 'g--', linewidth=2, label='Normalized Gaussian')

        x_cp, y_cp, y_tp = zip(*self.control_points)  # Unzip the list of tuples
        x_cp = [f"{float(x):.2f}" for x in [str(x) for x in x_cp]]
        ax.scatter(x_cp, y_cp, color='black', marker='x', zorder=5, s=100, label='Control Points')
        ax.scatter(x_cp, y_tp, color='black', marker='^', zorder=5, s=30, label='Control Points')
        # y_no = self.g(0.651)
        # ax.plot(X_labels, y_no, 'g--', linewidth=2, label='Normalized Gaussian')

        # y_norm_r = (max_y - (y_tp[3] - y_cp[3])) * (y_norm - max_y) / max_y + max_y# + (y_tp[4] - y_cp[4])
        # x.plot(X_labels, y_norm_r, 'g--', color='b',linewidth=2, label='Normalized Gaussian_r')

        ax.grid(True, linestyle='--', linewidth=0.5, color='gray')
        ax.set_xlabel('Bin Range')
        ax.set_ylabel('Percentage (%)')
        ax.set_xticks(X_labels[::tick])
        ax.set_xticklabels(X_labels[::tick], rotation=0)
        ax.legend(loc='upper right')
        plt.title(f'Distribution of Output Data in Different Bins{self.num_bins}')
        plt.show()

        all_x_cp_percentages = []

        for control_point in self.control_points:
            x_cp = control_point[0]  # 获取控制点的 x 坐标
            # 使用 x_cp 查找对应的索引
            target_x = "{:.2f}".format(x_cp)
            if target_x in X_labels:
                target_index = X_labels.index(target_x)
                # 使用索引获取对应的百分比
                target_percentage = percentage[target_index]
                all_x_cp_percentages.append(target_percentage)
        #print("所有 x_cp 对应的百分比:", all_x_cp_percentages)

def plotND(file_path, column_index, num_bins, relative=None, sampling_mode=None, ):
    d = DataAnalyzer(file_path, column_index, num_bins, relative)
    d.plot_data()
    if sampling_mode is not None:
         d.balance_data(sampling_mode)

if __name__ == "__main__":
    plotND('TB/sup.txt', '-1', 50, True)
    plotND('TB/sup.txt', '-1', 50, True, 'full')

"""
This class performs data balancing based on a specified sampling mode and a target normal distribution.

Parameters:
- file_path: The path to the input text file containing the data to be balanced.
- num_bins: The number of bins to use for discretizing the data, essentially setting the resolution for data processing.
- "relative": Set to True if the distribution should be relative to a Normal Distribution; otherwise, use an Absolute Normal Distribution.
- sampling_mode: Specifies the sampling strategy for data balancing within each bin. Options include:
    - "full": Fully sample by both quotient and residual counts.
    - "partial": Partially sample based on the formula: round(true * (revise - true) / revise).
    - "residual": Sample only by the residual count.
    - "average": Randomly samples rows to fill the DataFrame up to the specified maximum size, max_y.



Note: The `sampling_mode` parameter must be set for data to be balanced according to the target normal distribution.

Usage:
1. Before balancing the data with a normal distribution, use `num_bins` to visualize the data distribution by plotting it.
2. Choose the optimal `num_bins` where the plotted distribution neither has spikes nor cracks.
3. Once the optimal `num_bins` is determined, proceed with the data balancing.
"""

class Estopping:
    def __init__(self, min_delta=0.0001 ):
        self.min_delta = min_delta
        self.wait = 0  # Counter for patience
        self.stopped_epoch = 0
        self.best_loss = float('inf')  # Initialize the best as infinity.

    def on_epoch_end(self, epoch, current_loss, patience):

        if self.best_loss - current_loss > self.min_delta:
            self.best_loss = current_loss
            self.wait = 0
        else:
            self.wait += 1
            if self.wait >= patience:
                self.stopped_epoch = epoch
                return True  # Stop training
        return False  # Continue training

class ReduceLR:
    def __init__(self, optimizer, factor=0.1, min_delta=0.0001, min_lr=0.000001):
        self.factor = factor
        self.min_delta = min_delta
        self.optimizer = optimizer
        self.wait = 0  # Counter for patience
        self.best_loss = float('inf')  # Initialize the best as infinity.
        self.min_lr = min_lr

    def on_epoch_end(self, epoch, current_loss, patience):
        if self.best_loss - current_loss > self.min_delta:
            self.best_loss = current_loss
            self.wait = 0
        else:
            self.wait += 1
            if self.wait >= patience:
                old_lr = float(self.optimizer.learning_rate)
                new_lr = old_lr * self.factor
                new_lr = max(new_lr, self.min_lr)
                #print(f"Reducing learning rate from {old_lr} to {new_lr}")
                self.optimizer.learning_rate.assign(new_lr)
                self.wait = 0  # Reset the counter
        return (self.optimizer.learning_rate)


class AttentionLayer(layers.Layer):
    def __init__(self, units, **kwargs):
        super(AttentionLayer, self).__init__(**kwargs)
        self.units = units  # 注意这一行
        self.W1 = layers.Dense(units)
        self.W2 = layers.Dense(units)
        self.V = layers.Dense(1)

    def call(self, features):
        score = tf.nn.tanh(self.W1(features) + self.W2(features))
        attention_weights = tf.nn.softmax(self.V(score), axis=1)
        context_vector = attention_weights * features
        context_vector = tf.reduce_sum(context_vector, axis=1)
        context_vector = tf.expand_dims(context_vector, axis=-1)  # Expand dimensions
        return context_vector

    def get_config(self):
        config = super().get_config()
        config.update({
            'units': self.units,
        })
        return config

class CustomModelBuilder:
    def __init__(self, input_shape, layer_configs, attention_units):
        self.input_shape = input_shape
        self.layer_configs = layer_configs
        self.attention_units = attention_units

    def build(self):
        input_layer = layers.Input(shape=self.input_shape)
        x = input_layer

        # 创建 Dense、Dropout 和正则化层
        for config in self.layer_configs:
            num_units = config['units']
            x = layers.Dense(num_units)(x)

            if config.get('use_regularizer', False):
                regularizer_rate = config.get('regularizer_rate', 0.01)
                x = layers.Dense(num_units, kernel_regularizer=regularizers.l2(regularizer_rate))(x)

            if config.get('use_dropout', False):
                dropout_rate = config.get('dropout_rate', 0.2)
                x = layers.Dropout(dropout_rate)(x)

        # 添加 Attention 层
        for _ in range(self.attention_units):
            x = AttentionLayer(config.get('attention_units', 32))(x)

        output_layer = layers.Dense(self.input_shape[0])(x)  # 假设输出层维度与输入层相同

        return models.Model(inputs=input_layer, outputs=output_layer)

