import pandas as pd
import os
from tqdm import tqdm
import numpy as np
import time
# from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
# from scipy.optimize import differential_evolution
# from scipy.optimize import minimize

def calculate(modis_temp, aster_temp):
    print("MODIS Temp Shape:", modis_temp.shape)
    print("ASTER Temp Shape:", aster_temp.shape)
    results = {}

    def calculate_metrics(y_true, y_pred):
        residuals = y_true - y_pred
        return {
            'RSS': np.sum(residuals ** 2),
            'R-squared': r2_score(y_true, y_pred),
            'RMSE': np.sqrt(mean_squared_error(y_true, y_pred)),
            'MAE': mean_absolute_error(y_true, y_pred),
        }
    metrics = calculate_metrics(modis_temp, aster_temp)

    for metric, value in metrics.items():
        print(f'  {metric}: {value:.4f}')

    residuals = modis_temp - aster_temp
    positive_residuals = residuals[residuals > 0]
    negative_residuals = residuals[residuals < 0]
    avg_pos_resid = positive_residuals.mean() if not positive_residuals.empty else 0
    avg_neg_resid = negative_residuals.mean() if not negative_residuals.empty else 0
    return avg_pos_resid, avg_neg_resid

# 定义scales和offsets数组（根据属�?5-6�?5-7的信息）
# 定义常数
h = 6.62607015e-34  # 普朗克常�?, 单位: J·s
c = 2.99792458e8    # 光�?, 单位: m/s
k = 1.380649e-23    # 玻尔兹曼常数, 单位: J/K
modis_wavelengths = np.array([7.325, 8.550, 9.730, 11.030, 12.020]) * 1e-6 # 波段中心波长，单位转换为�?
modis_map_wavelengths = np.array([7.811, 8.406,  8.582,  8.804, 9.411,  10.237, 10.844,  11.152, 11.664]) * 1e-6  #28,29, 29, 29,30, 30,31, 31, 32
modis_scales = np.array([0.00019245, 0.000532487, 0.000406323, 0.000840022, 0.000729698])   #28,19,30,31,32
modis_offsets = np.array([2317.48828125, 2730.58349609, 1560.33325195, 1577.33972168, 1658.22131348])
aster_wavelengths = np.array([8.3, 8.65, 9.1, 10.6, 11.3]) * 1e-6

lst_scale = np.array([0.02, 0.04, 1])
uncertainty = {0: 2.8125, 1: 10., 2: 2, 3: 2, 4: 2, 5: 2, 6: 2, 7: 2, 8: 2, 9: 1.5, 10: 1.5, 11: 2, 12: 2, 13: 2, 14: 2, 15: 2}

gain = np.array([6.822, 6.780, 6.590, 5.692, 5.225]) * 1e-3
aster_wavelengths = np.array([8.3, 8.65, 9.1, 10.6, 11.3]) * 1e-6
aster_lst_scale = np.array([0.1])
aster_em_scale = np.array([0.001, 0.001, 0.001, 0.001, 0.001])
#0.795:0.204  0.466:0.534   0.669:0.331   0.273:0.727
#0.822:0.178  0.488:0.512   0.598:0.402   0.289:0.711
def process_m_a_filt(file_path):
    df = pd.read_csv(file_path, sep="\t", header=None, skiprows=3)
    header_lines = pd.read_csv(file_path, sep="\t", header=None, nrows=3)
    modis_radiance = modis_scales * (df.iloc[:, 0:5]   - modis_offsets)
    modis_radiance = df.iloc[:, 0:5]
    modis_em_temp = np.where(df.iloc[:, 0:5] <= 0, 0,
                          (h * c) / (k * modis_wavelengths * np.log((2 * h * c ** 2) / (modis_wavelengths ** 5 * modis_radiance * 1e6) + 1)))
    modis_em_temp = pd.DataFrame(modis_em_temp)#, columns=df.columns[0:5])
    modis_em_temp = modis_em_temp.round(2)

    aster_radiance = gain * (df.iloc[:, 5:10] - 1)
    aster_em_temp = np.where(df.iloc[:, 5:10] <= 0, 0,
                            (h * c) / (k * aster_wavelengths * np.log(((2 * h * c ** 2) / (aster_wavelengths ** 5 * aster_radiance * 1e6)) + 1)))
    aster_em_temp = pd.DataFrame(aster_em_temp)#, columns=df.columns[5:10])
    aster_em_temp = aster_em_temp.round(2)
    data = pd.concat([df, modis_em_temp, aster_em_temp], axis=1)
    data = pd.DataFrame(data)
    print("Data Shape:", data.shape)

    # 初始化需要删除的行标记
    rows_to_delete = np.zeros(data.shape[0], dtype=bool)

    # 计算前十列的四分位数范围
    for col in range(10):
        series_col = data.iloc[:, col]  # 获取单列数据作为 Series
        Q1 = series_col.quantile(0.25)
        Q3 = series_col.quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR

        outliers = (series_col < lower_bound) | (series_col > upper_bound)
        rows_to_delete |= outliers  # 更新标记数组
        print(f'Comparison {col} - Q1: {Q1:.4f}, Q3: {Q3:.4f}, IQR: {IQR:.4f}, Lower Bound: {lower_bound:.4f}, Upper Bound: {upper_bound:.4f}, Outliers: {np.sum(outliers)}')


    # 计算偏差列的四分位数范围
    comparisons = [
        (16, 11), (17, 11), (17, 12), (17, 13),
        (18, 13), (18, 14), (19, 14), (19, 15), (20, 15)
    ]

    for col1, col2 in comparisons:
        series_col1 = data.iloc[:, col1 - 1]
        series_col2 = data.iloc[:, col2 - 1]
        deviation = series_col1 - series_col2

        Q1 = deviation.quantile(0.25)
        Q3 = deviation.quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR

        outliers = (deviation < lower_bound) | (deviation > upper_bound)
        rows_to_delete |= outliers
        print(f'Comparison {col1} - {col2} - Q1: {Q1:.4f}, Q3: {Q3:.4f}, IQR: {IQR:.4f}, Lower Bound: {lower_bound:.4f}, Upper Bound: {upper_bound:.4f}, Outliers: {np.sum(outliers)}')


    # 删除包含离群点的行
    cleaned_data = data[~rows_to_delete]


    deviations = [
        (data.iloc[:, 15] - data.iloc[:, 10], '第十六列减去第十一列'),
        (data.iloc[:, 16] - data.iloc[:, 10], '第十七列减去第十一列'),
        (data.iloc[:, 16] - data.iloc[:, 11], '第十七列减去第十二列'),
        (data.iloc[:, 16] - data.iloc[:, 12], '第十七列减去第十三列'),
        (data.iloc[:, 17] - data.iloc[:, 12], '第十八列减去第十三列'),
        (data.iloc[:, 17] - data.iloc[:, 13], '第十八列减去第十四列'),
        (data.iloc[:, 18] - data.iloc[:, 13], '第十九列减去第十四列'),
        (data.iloc[:, 18] - data.iloc[:, 14], '第十九列减去第十五列'),
        (data.iloc[:, 19] - data.iloc[:, 14], '第二十列减去第十五列')
    ]
    cleaned_deviations = [
        (cleaned_data.iloc[:, 15] - cleaned_data.iloc[:, 10], '第十六列减去第十一列'),
        (cleaned_data.iloc[:, 16] - cleaned_data.iloc[:, 10], '第十七列减去第十一列'),
        (cleaned_data.iloc[:, 16] - cleaned_data.iloc[:, 11], '第十七列减去第十二列'),
        (cleaned_data.iloc[:, 16] - cleaned_data.iloc[:, 12], '第十七列减去第十三列'),
        (cleaned_data.iloc[:, 17] - cleaned_data.iloc[:, 12], '第十八列减去第十三列'),
        (cleaned_data.iloc[:, 17] - cleaned_data.iloc[:, 13], '第十八列减去第十四列'),
        (cleaned_data.iloc[:, 18] - cleaned_data.iloc[:, 13], '第十九列减去第十四列'),
        (cleaned_data.iloc[:, 18] - cleaned_data.iloc[:, 14], '第十九列减去第十五列'),
        (cleaned_data.iloc[:, 19] - cleaned_data.iloc[:, 14], '第二十列减去第十五列')
    ]
    # 打印前十列的均值和标准差（筛选前）
    for col in range(10):
        mean = df.iloc[:, col].mean()
        std_dev = df.iloc[:, col].std()
        print(f'Column {col} - Mean (before): {mean:.4f}, Std Dev (before): {std_dev:.4f}')

    # 打印后九组偏差的均值和标准差（筛选前）
    for deviation, description in deviations:
        mean = deviation.mean()
        std_dev = deviation.std()
        print(f'{description} - Mean (before): {mean:.4f}, Std Dev (before): {std_dev:.4f}')
    cleaned_data = pd.DataFrame(cleaned_data)
    # 打印前十列的均值和标准差（筛选后）
    for col in range(10):
        mean = cleaned_data.iloc[:, col].mean()
        std_dev = cleaned_data.iloc[:, col].std()
        print(f'Column {col} - Mean: {mean:.4f}, Std Dev: {std_dev:.4f}')

    # 打印后九组偏差的均值和标准差（筛选后）
    for deviation, description in cleaned_deviations:
        mean = deviation.mean()
        std_dev = deviation.std()
        print(f'{description} - Mean: {mean:.4f}, Std Dev: {std_dev:.4f}')
   
    
    
    # 打印删除前后数据的形状
    output_file = os.path.join(os.path.dirname(file_path), "d", "d" + os.path.basename(file_path))
    print(f"Saved cleaned file: {output_file}")
    print(f"原始行数: {data.shape[0]}")
    print(f"新行数: {cleaned_data.shape[0]}")



    # 仅保留前十列
    cleaned_data = cleaned_data.iloc[:, :10]
    cleaned_data.to_csv(output_file, index=False, header=False, sep='\t')

def process_m_a(file_path):
    df = pd.read_csv(file_path, sep="\t", header=None, skiprows=3)
    header_lines = pd.read_csv(file_path, sep="\t", header=None, nrows=3)
    modis_radiance = modis_scales * (df.iloc[:, 0:5]   - modis_offsets)
    modis_radiance = df.iloc[:, 0:5]
    modis_em_temp = np.where(df.iloc[:, 0:5] <= 0, 0,
                       (h * c) / (k * modis_wavelengths * np.log((2 * h * c ** 2) / (modis_wavelengths ** 5 * modis_radiance * 1e6) + 1)))
    modis_em_temp = pd.DataFrame(modis_em_temp)#, columns=df.columns[0:5])
    modis_em_temp = modis_em_temp.round(2)

    aster_radiance = gain * (df.iloc[:, 5:10] - 1)
    aster_em_temp = np.where(df.iloc[:, 5:10] <= 0, 0,
                       (h * c) / (k * aster_wavelengths * np.log(((2 * h * c ** 2) / (aster_wavelengths ** 5 * aster_radiance * 1e6)) + 1)))
    aster_em_temp = pd.DataFrame(aster_em_temp)#, columns=df.columns[5:10])
    aster_em_temp = aster_em_temp.round(2)

    def mapping(modis_radiance, map_wavelengths):
        modis_radiance = pd.DataFrame(modis_radiance)
        modis_mapping_radiance = pd.concat([
            modis_radiance.iloc[:, 0],  # 列28
            modis_radiance.iloc[:, 1],  # 列29 第一次
            modis_radiance.iloc[:, 1],  # 列29 第二次
            modis_radiance.iloc[:, 1],  # 列29 第三次
            modis_radiance.iloc[:, 2],  # 列30 第一次
            modis_radiance.iloc[:, 2],  # 列30 第二次
            modis_radiance.iloc[:, 3],  # 列31 第一次
            modis_radiance.iloc[:, 3],  # 列31 第二次
            modis_radiance.iloc[:, 4]], axis=1)
        modis_map_temp = np.where(modis_mapping_radiance.iloc[:, 0:9] <= 0, 0,
                        (h * c) / (k * map_wavelengths * np.log((2 * h * c ** 2) / (map_wavelengths ** 5 * modis_mapping_radiance  * 1e6) + 1)))
        modis_map_temp = pd.DataFrame(modis_map_temp)
        return modis_map_temp
    modis_map_temp = mapping(modis_radiance, modis_map_wavelengths)
    
    #value = [0.795, 0.204,  1, 0.466, 0.534, 0.669, 0.331, 0.273, 0.727]
    values = [0.822, 0.178, 1, 0.488, 0.512, 0.598, 0.402, 0.289, 0.711]


    modis_map_temp = pd.concat([
        values[1] * modis_map_temp.iloc[:, 0] + values[0] * modis_map_temp.iloc[:, 1],# + 4.6657 ,
        values[2] * modis_map_temp.iloc[:, 2] ,#- 0.28455,
        values[4] * modis_map_temp.iloc[:, 3] + values[3] * modis_map_temp.iloc[:, 4] ,#+ 12.2918,
        values[6] * modis_map_temp.iloc[:, 5] + values[5] * modis_map_temp.iloc[:, 6] ,#+ 14.22315,
        values[8] * modis_map_temp.iloc[:, 7] + values[7] * modis_map_temp.iloc[:, 8] ,#+ 0.90740
    ], axis=1)
    modis_map_temp = pd.DataFrame(modis_map_temp)
    modis_map_temp = modis_map_temp.round(2)
    print("Modis Emission Temp Shape:", modis_em_temp.shape) 
    print("Aster Emission Temp Shape:", aster_em_temp.shape)
    print("Modis Map Temp Shape:", modis_map_temp.shape)

    data = pd.concat([modis_em_temp, aster_em_temp, modis_map_temp], axis=1)
    from algorithms.datadeal import DataProcessor
    DataProcessor.calculate(data)

    #求value中的九个未知数，使得pos_resid和neg_resid的绝对值之差最小
    #即求下面五个方程组的解
    #求value[0],value[1],使得pos_resid[0]和neg_resid[0]的绝对值之差最小
    #求value[2],使得pos_resid[1]和neg_resid[1]的绝对值之差最小
    #求value[3],value[4],使得pos_resid[2]和neg_resid[2]的绝对值之差最小
    #求value[5],value[6],使得pos_resid[3]和neg_resid[3]的绝对值之差最小
    #求value[7],value[8],使得pos_resid[4]和neg_resid[4]的绝对值之差最小

    

    print("Data Shape:", data.shape)


    #final_data = pd.concat([header_lines, data], ignore_index=True)
    
    

    # 结果保存
    #processed_file_path = os.path.join(os.path.dirname(file_path), 'r', 'r' + os.path.basename(file_path))
    processed_file_path = os.path.join(f'data/mapping/test', 'r' + os.path.basename(file_path))
    data.to_csv(processed_file_path, sep='\t', index=False, header=False)

def process_ma(file_path):
    df = pd.read_csv(file_path, sep="\t", header=None, skiprows=3)
    header_lines = pd.read_csv(file_path, sep="\t", header=None, nrows=3)
    modis_radiance = modis_scales * (df.iloc[:, 0:5]   - modis_offsets)
    modis_radiance = df.iloc[:, 0:5]
    modis_em_temp = np.where(df.iloc[:, 0:5] <= 0, 0,
                       (h * c) / (k * modis_wavelengths * np.log((2 * h * c ** 2) / (modis_wavelengths ** 5 * modis_radiance * 1e6) + 1)))
    modis_em_temp = pd.DataFrame(modis_em_temp)#, columns=df.columns[0:5])
    modis_em_temp = modis_em_temp.round(2)

    aster_radiance = gain * (df.iloc[:, 5:10] - 1)
    aster_em_temp = np.where(df.iloc[:, 5:10] <= 0, 0,
                       (h * c) / (k * aster_wavelengths * np.log(((2 * h * c ** 2) / (aster_wavelengths ** 5 * aster_radiance * 1e6)) + 1)))
    aster_em_temp = pd.DataFrame(aster_em_temp)#, columns=df.columns[5:10])
    aster_em_temp = aster_em_temp.round(2)

    data = pd.concat([modis_em_temp, aster_em_temp], axis=1)
    processed_file_path = os.path.join(f'data/mapping/test', 'r' + os.path.basename(file_path))
    data.to_csv(processed_file_path, sep='\t', index=False, header=False)

def process_modis(file_path):
    df = pd.read_csv(file_path, sep="\t", header=None, skiprows=3)
    header_lines = pd.read_csv(file_path, sep="\t", header=None, nrows=3)
    modis_radiance = modis_scales * (df.iloc[:, 0:5]   - modis_offsets)
    modis_radiance = df.iloc[:, 0:5]
    modis_em_temp = np.where(df.iloc[:, 0:5] <= 0, 0,
                       (h * c) / (k * modis_wavelengths * np.log((2 * h * c ** 2) / (modis_wavelengths ** 5 * modis_radiance * 1e6) + 1)))
    modis_em_temp = pd.DataFrame(modis_em_temp)#, columns=df.columns[0:5])
    modis_em_temp = modis_em_temp.round(3)
    #emis = 0.002 * df.iloc[:, 5:7] + 0.49
    emis = np.where(df.iloc[:, 5:7] <= 0 , 0, (0.002 * df.iloc[:, 5:7] + 0.49))
    emis = emis.round(3)
    lst = 0.02 * df.iloc[:, 7]
    lst = lst.round(2)##
    qc = df.iloc[:, 8].round(0)
    
    emis = pd.DataFrame(emis)
    lst = pd.DataFrame(lst)
    qc = pd.DataFrame(qc)

    data = pd.concat([modis_em_temp, emis, lst, qc], axis=1)
    processed_file_path = os.path.join("data//rmodis", 'r' + os.path.basename(file_path))
    data.to_csv(processed_file_path, sep='\t', index=False, header=False)

def inver_modis(file_path):
    df = pd.read_csv(file_path, sep="\t", header=None, skiprows=3)
    inver = (df.iloc[:, 0:5] / modis_scales) + modis_offsets
    inver = inver.round(0).astype(int) 
    emtq = df.iloc[:, 5:9].round(0).astype(int) 
    inver  = pd.DataFrame(inver)
    emtq = pd.DataFrame(emtq)
    data = pd.concat([inver, emtq], axis=1)
    processed_file_path = os.path.join("data//GPT//Grmodis", 'r' + os.path.basename(file_path))
    data.to_csv(processed_file_path, sep='\t', index=False, header=False)


# 定义计算函数
def process_modis_(file_path):
    # 数据读取
    df = pd.read_csv(file_path, sep="\t", header=None, skiprows=3)

    # 头部信息处理
    header_lines = pd.read_csv(file_path, sep="\t", header=None, nrows=3)

    # 数据处理1-3
    llh = df.iloc[:, 0:3]
    llh.iloc[:, 2] = llh.iloc[:, 2].round(0)

    # 数据处理4-9
    radiance = modis_scales * (df.iloc[:, 3:9]- modis_offsets)
    em_temp = np.where(df.iloc[:, 3:9] <= 0, 0,
                       (h * c) / (k * modis_wavelengths * np.log((2 * h * c ** 2) / (modis_wavelengths ** 5 * radiance * 1e6) + 1)))
    em_temp = pd.DataFrame(em_temp, columns=df.columns[3:9])
    em_temp = em_temp.round(2)

    # 数据处理10-15
    emU = df.iloc[:, 9:15].replace(uncertainty)

    # 数据处理16-17
    lst = lst_scale * df.iloc[:, 15:18]
    lst.iloc[:, 0] = lst.iloc[:, 0].round(2)

    # 数据处理18
    #lst_qc = df.iloc[:, 17].apply(lambda x: bin(int(x))[2:].zfill(16))


    # 结果合并
    data = pd.concat([llh, em_temp, emU, lst], axis=1)
    final_data = pd.concat([header_lines, data], ignore_index=True)

    # 结果保存
    processed_file_path = os.path.join(os.path.dirname(file_path), 'r' + os.path.basename(file_path))
    final_data.to_csv(processed_file_path, sep='\t', index=False, header=False)
    
def process_aster(file_path):
    # 数据读取
    df = pd.read_csv(file_path, sep="\t", header=None, skiprows=3)

    # 头部信息处理
    header_lines = pd.read_csv(file_path, sep="\t", header=None, nrows=3)

    radiance = gain * (df.iloc[:, :5] - 1)
    em_temp = np.where(df.iloc[:, :5] <= 0, 0,
                       (h * c) / (k * aster_wavelengths * np.log(((2 * h * c ** 2) / (aster_wavelengths ** 5 * radiance * 1e6)) + 1)))
    em_temp = pd.DataFrame(em_temp, columns=df.columns[:5])
    em_temp = em_temp.round(2)
    lst = aster_lst_scale * df.iloc[:, 10]
    lst = lst.round(2)
    em = aster_em_scale * df.iloc[:, 5:10]
    em = em.round(3)
    data = pd.concat([em_temp, em, lst,], axis=1)
    final_data = pd.concat([header_lines, data], ignore_index=True)
    processed_file_path = os.path.join(os.path.dirname(file_path), 'r', 'r' + os.path.basename(file_path))
    os.makedirs(os.path.dirname(processed_file_path), exist_ok=True)
    final_data.to_csv(processed_file_path, sep='\t', index=False, header=False)

if __name__ == "__main__":
    # 调用函数处理数据
    start = time.time()
    #process_modis('E:/Gu/MODIS/deal/txt/part/cll.txt')
    process_aster('F:\\data\\txt\\combine\\ctest1.txt')

    print(f"代码运行时间：{time.time() - start:.2f} �?")


    # 示例使用
    files_to_concat = ['/path/to/file1.txt', '/path/to/file2.txt', '/path/to/file3.txt']
    concat(files_to_concat)


